# pytesting syntax basics

#### why `mock_task = MagicMock()` and then `mock_task.delay.return_value = mock_task` ?
thats like saying mock_task is a object(instance of the class) and then the method is its own object?

```py
class TestConcurrentFileUploads:
    """test concurrent file upload race conditions."""

    def test_10_concurrent_uploads_all_succeed(
        self, test_client, sample_mp3_bytes, temp_upload_dir
    ):
        """test that concurrent uploads all succeed"""
        # mock celery task to avoid actual processing
        mock_task = MagicMock()
        mock_task.id = "test-task-id"
        mock_task.delay.return_value = mock_task


#celery code looks like:
result = task.delay(...)
task_id = result.id

from unittest.mock import MagicMock

# Create one fake object
mock_task = MagicMock()

# Give it an id, like Celery's AsyncResult.id
mock_task.id = "test-task-id"

# Accessing .delay creates another MagicMock automatically
# mock_task.delay is now a callable MagicMock

# Tell that callable:
# "when someone calls delay(), return mock_task"
mock_task.delay.return_value = mock_task

# Now see what happens step by step:

a = mock_task.delay      # a is a MagicMock (the fake "method")
b = a()                  # b is mock_task, because we set return_value
c = b.id                 # "test-task-id"

print(c)                 # → "test-task-id"


# This is why this works:
# mock_task.delay().id
# → (call delay) → mock_task
# → (get id) → "test-task-id"

# mock_task.delay.return_value is 
tmp = mock_task.delay        # tmp is a MagicMock
tmp.return_value = mock_task # Only its return_value points back to mock_task
mock_task
 └── delay → MagicMock
          └── return_value → mock_task

# if you wrote mock_task.delay = mock_task then obj.attr = obj
# You didn’t make the attribute equal the object — you made the result of calling the attribute equal the object.
# MagicMock() is a fake object that automatically creates more fake objects when you touch it.
```

#### in test_all_db_records_created_with_unique_ids why use a list for task_count?

```py
        task_count = [0] 

        def mock_delay(*args, **kwargs):
            task_count[0] += 1 
            mock_result = MagicMock()
            mock_result.id = f"task-{task_count[0]}"
            return mock_result


x = 5
def f():
    x = 10 # this x is local to f

task_count = 0
def mock_delay():
    task_count += 1 # error

#solution
task_count = 0
def mock_delay():
    nonlocal task_count
    task_count += 1

# use a mutable object (list) so you can change it without rebinding
task_count = [0]
def mock_delay():
    task_count[0] += 1

# you can do this but we dont really want to use task_count, we mock_delay() to update shared state each call. 
task_count = 0
def mock_delay(task_count):
    task_count += 1
    return task_count
task_count = mock_delay(task_count)
```

####  test_concurrent_filename_generation_thread_safe really test threadsafety