# Audio Transcription API - Technical Defense Study Guide

**Last Updated**: January 2026
**Purpose**: Comprehensive technical reference for explaining architecture, design patterns, and implementation decisions

---

## Table of Contents

1. [Project Overview & Context](#1-project-overview--context)
2. [Architectural Design Patterns](#2-architectural-design-patterns)
3. [Security Architecture](#3-security-architecture)
4. [Database & Data Layer](#4-database--data-layer)
5. [ML Model Integration](#5-ml-model-integration)
6. [API Design & FastAPI Features](#6-api-design--fastapi-features)
7. [Async I/O & Performance](#7-async-io--performance)
8. [Background Task Processing (Celery + Redis)](#8-background-task-processing-celery--redis)
9. [Configuration Management](#9-configuration-management)
10. [Testing Strategy](#10-testing-strategy)
11. [Frontend Architecture](#11-frontend-architecture)
12. [Design Trade-offs & Decisions](#12-design-trade-offs--decisions)
13. [Production vs Assessment Comparison](#13-production-vs-assessment-comparison)
14. [Deployment Considerations](#14-deployment-considerations)
15. [Technical Deep Dives](#15-technical-deep-dives)
16. [Presentation Defense Strategy](#16-presentation-defense-strategy)
17. [Quick Reference](#17-quick-reference)

---

## 1. Project Overview & Context

### 1.1 What This Application Does

An audio transcription API that accepts MP3 files and returns text transcriptions using OpenAI's Whisper model.

**Core Workflow**:
1. User uploads MP3 file via REST API
2. System validates file (type, size, content)
3. File saved with unique timestamped filename
4. Whisper model transcribes audio to text
5. Transcription stored in database
6. User can search/retrieve past transcriptions

### 1.2 Technology Stack

**Backend** (`backend/src/`):
- **FastAPI**: Modern async web framework for Python
- **SQLAlchemy 2.0**: Type-safe ORM with async support
- **SQLite**: Embedded database (assessment only)
- **Celery**: Distributed task queue for async processing
- **Redis**: Message broker + result backend for Celery
- **Whisper (HuggingFace Transformers)**: Speech-to-text ML model
- **PyTorch**: ML framework (CPU/MPS/CUDA device detection)
- **python-magic**: MIME type validation via libmagic
- **google-re2**: Linear-time regex for ReDoS protection
- **slowapi**: IP-based rate limiting
- **pytest**: 93+ unit/integration tests

**Frontend** (`frontend/src/`):
- **React 18 + TypeScript**: Type-safe component library
- **Vite**: Fast build tool and dev server
- **TailwindCSS**: Utility-first styling

**DevOps**:
- **uv**: Fast Python package manager
- **pre-commit**: Automated code quality checks (ruff, mypy)
- **Docker**: Containerization (optional)

### 1.3 Project Structure

```
backend/
├── src/
│   ├── main.py                    # FastAPI app, routes, lifespan
│   ├── celery_app.py              # Celery app, async tasks
│   ├── services/
│   │   ├── whisper_service.py     # Singleton model service
│   │   ├── file_service.py        # Multi-layer file validation
│   │   └── transcription_service.py  # Orchestration service layer
│   └── utils/
│       ├── db.py                  # SQLAlchemy models, repository
│       ├── security.py            # Sanitization functions
│       ├── settings.py            # Singleton configuration
│       └── schemas.py             # Pydantic response models
└── tests/
    ├── unit/                      # 93 unit tests
    │   ├── test_security.py       # Security attack tests
    │   ├── test_file_service.py   # File sanitization tests
    │   ├── test_repository.py     # Database CRUD tests
    │   └── test_whisper_service.py # Model singleton tests
    └── integration/               # End-to-end API tests
        ├── test_health_endpoint.py
        ├── test_file_upload_security.py
        └── test_transcription_workflow.py
```

<details>
<summary><strong>Why this structure?</strong></summary>

**Separation of Concerns**:
- **Services**: Business logic (transcription workflow, model caching)
- **Utils**: Infrastructure (database, security, config)
- **Main**: API layer (routing, middleware, lifecycle)

This makes code:
- **Testable**: Mock services without touching I/O
- **Maintainable**: Change implementation without affecting routes
- **Scalable**: Add new services without refactoring existing code
</details>

---

## 2. Architectural Design Patterns

### 2.1 Singleton Pattern (WhisperModelService)

<details>
<summary><strong>What is a Singleton?</strong></summary>

A design pattern that ensures only **one instance** of a class exists throughout the application lifecycle. Multiple requests to create the class return the same shared instance.
</details>

**Why Singleton for Whisper?**

The Whisper Tiny model:
- Size: ~150MB in memory
- Load time: 5-10 seconds on first load
- Immutable after loading (no state changes)

Loading per-request would:
- ❌ Exhaust memory (potentially 100+ instances under load)
- ❌ Add 5-10s latency to every request
- ❌ Waste GPU/CPU resources reloading identical model

**Implementation** (`src/services/whisper_service.py:27-33`):

```python
class WhisperModelService:
    _instance: "WhisperModelService | None" = None
    _lock: threading.Lock = threading.Lock()
    _initialized: bool = False

    def __new__(cls) -> "WhisperModelService":
        """Create singleton instance with double-checked locking."""
        if cls._instance is None:              # First check (fast path)
            with cls._lock:                    # Acquire lock
                if cls._instance is None:      # Second check (thread-safe)
                    cls._instance = super().__new__(cls)
        return cls._instance
```

**Performance Impact**:
- First request: ~10 seconds (model loading + transcription)
- Subsequent requests: <1 second (transcription only)
- Memory: 150MB total vs potentially 15GB+ without singleton

**Thread Safety**:
- **Double-checked locking**: Check `_instance` before/after acquiring lock
- **Why?** Prevents race condition where Thread A and Thread B both see `None`, both try to create instance
- **First check**: Fast path for already-initialized case (no lock needed)
- **Second check**: Inside lock to ensure only one thread creates instance

<details>
<summary><strong>Trade-offs of Singleton Pattern</strong></summary>

**Pros**:
- Memory efficiency (one instance)
- Fast response times after first load
- Simple global access

**Cons**:
- Global state (generally discouraged in modern design)
- Harder to test (can't easily swap implementations)
- Couples code to specific implementation

**Why acceptable here?**
- Model is immutable (no shared mutable state issues)
- Performance benefit is massive
- Testing can mock `get_whisper_service()` factory function
- No need for multiple model variants in this assessment
</details>

### 2.2 Repository Pattern (TranscriptionRepository)

<details>
<summary><strong>What is a Repository?</strong></summary>

A pattern that encapsulates all database access logic behind a clean interface. The rest of the application interacts with the repository methods (like `create()`, `get_all()`) without knowing SQL or ORM details.
</details>

**Why Repository Pattern?**

**Without Repository** (tight coupling):
```python
# main.py - business logic mixed with database code
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile, db: Session):
    # ... file handling ...

    # Database code directly in route handler
    transcription = Transcription(
        audio_filename=filename,
        transcribed_text=text
    )
    db.add(transcription)
    db.commit()
    db.refresh(transcription)
    return transcription
```

**With Repository** (separation of concerns):
```python
# main.py - clean business logic
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile, db: Session):
    service = TranscriptionService(db, file_service, whisper_service)
    transcription = await service.process_transcription(file)
    return transcription

# db.py - database logic centralized
class TranscriptionRepository:
    def create(self, audio_filename: str, text: str) -> Transcription:
        transcription = Transcription(
            audio_filename=audio_filename,
            transcribed_text=text
        )
        self._db.add(transcription)
        self._db.commit()
        self._db.refresh(transcription)
        return transcription
```

**Benefits**:
- **Testability**: Mock repository without database
- **Maintainability**: Change database schema in one place
- **Reusability**: Same methods for API routes, background jobs, CLI tools
- **Separation of Concerns**: Route handlers focus on HTTP, repositories handle data

**Implementation** (`src/utils/db.py:78-111`):

```python
class TranscriptionRepository:
    """Repository for transcription CRUD operations."""

    def __init__(self, db: Session) -> None:
        self._db = db

    def create(self, audio_filename: str, transcribed_text: str) -> Transcription:
        """Create new transcription record."""
        transcription = Transcription(
            audio_filename=audio_filename,
            transcribed_text=transcribed_text,
        )
        self._db.add(transcription)
        self._db.commit()
        self._db.refresh(transcription)
        return transcription

    def get_all(self) -> Sequence[Transcription]:
        """Get all transcriptions, ordered by most recent first."""
        stmt = select(Transcription).order_by(
            Transcription.created_timestamp.desc()
        )
        return self._db.execute(stmt).scalars().all()

    def search_by_filename(self, filename_query: str) -> Sequence[Transcription]:
        """Search transcriptions by filename (partial match)."""
        stmt = (
            select(Transcription)
            .where(Transcription.audio_filename.contains(filename_query))
            .order_by(Transcription.created_timestamp.desc())
        )
        return self._db.execute(stmt).scalars().all()
```

### 2.3 Service Layer Pattern (TranscriptionService)

<details>
<summary><strong>What is a Service Layer?</strong></summary>

A pattern that orchestrates business logic by coordinating multiple lower-level services. It defines the application's use cases and workflows, keeping route handlers thin and focused on HTTP concerns.
</details>

**Why Service Layer?**

**Problem**: Route handlers shouldn't contain complex business logic:
- Hard to test (requires mocking FastAPI request/response)
- Hard to reuse (can't call from CLI, background jobs, etc.)
- Violates Single Responsibility Principle

**Solution**: Extract workflow orchestration into a service:

```python
# src/services/transcription_service.py:28-53
class TranscriptionService:
    """Service to orchestrate transcription workflow."""

    def __init__(
        self,
        db: Session,
        file_service: FileService,
        whisper_service: WhisperModelService,
    ):
        self._file_service = file_service
        self._whisper_service = whisper_service
        self._repository = TranscriptionRepository(db)

    async def process_transcription(self, file: UploadFile) -> Transcription:
        """Process complete transcription workflow.

        Steps:
        1. Validate file (extension, size, MIME type)
        2. Save file with unique name
        3. Transcribe audio using Whisper
        4. Save transcription to database
        5. Clean up on failure
        """
        # Multi-layer validation
        self._file_service.validate_file(file)
        filename, file_path = await self._file_service.save_file(file)

        try:
            # Transcribe and persist
            transcribed_text = self._whisper_service.transcribe(file_path)
            transcription = self._repository.create(
                audio_filename=filename,
                transcribed_text=transcribed_text,
            )
            return transcription

        except Exception as e:
            # Transaction-like cleanup: delete file if DB save fails
            self._file_service.delete_file(filename)
            raise
```

**Benefits**:
- **Thin route handlers**: Only handle HTTP concerns (parsing, validation, serialization)
- **Reusable logic**: Service can be called from routes, CLI, background jobs
- **Easy testing**: Test service without FastAPI overhead
- **Transaction-like behavior**: Cleanup on failure (delete file if DB save fails)

**Route Handler** (`src/main.py:104-126`):
```python
@app.post("/api/v1/transcribe")
async def transcribe_audio(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    file_service: FileService = Depends(get_file_service),
    whisper_service: WhisperModelService = Depends(get_whisper_service),
) -> TranscriptionResponse:
    """Upload and transcribe audio file."""
    # All business logic delegated to service
    service = TranscriptionService(db, file_service, whisper_service)
    transcription = await service.process_transcription(file)

    # Route only handles response serialization
    return TranscriptionResponse(
        id=transcription.id,
        audio_filename=transcription.audio_filename,
        transcribed_text=transcription.transcribed_text,
        created_timestamp=transcription.created_timestamp,
    )
```

### 2.4 Dependency Injection (FastAPI `Depends()`)

<details>
<summary><strong>What is Dependency Injection?</strong></summary>

A pattern where objects receive their dependencies from external code rather than creating them internally. Instead of `service = EmailClient("smtp.example.com")` hard-coded, you inject the dependency: `service: EmailClient = Depends(get_email_client)`.
</details>

**Why Dependency Injection?**

Three main problems DI solves:

1. **Hidden Coupling**: Hard-wired dependencies make replacement difficult
2. **Testability**: Real services (DB, external APIs) get pulled into tests
3. **Configurability**: Switching implementations (prod vs mock) requires code edits

**Example: Without DI** (hard-wired):
```python
# Every endpoint creates its own mailer - changing config requires editing all routes
@app.post("/orders/{id}/confirm")
async def confirm_order(id: str):
    mailer = EmailClient("smtp.prod.example.com")  # Hard-coded
    mailer.send("user@example.com", "Order confirmed", "Thanks!")
    return {"ok": True}

@app.post("/invoices/{id}/send")
async def send_invoice(id: str):
    mailer = EmailClient("smtp.prod.example.com")  # Duplicated
    mailer.send("user@example.com", "Your invoice", "PDF attached")
    return {"ok": True}
```

**Example: With DI** (flexible):
```python
# Factory function - single configuration point
def get_mailer() -> EmailClient:
    return EmailClient("smtp.prod.example.com")  # Change once, affects all routes

@app.post("/orders/{id}/confirm")
async def confirm_order(
    id: str,
    mailer: EmailClient = Depends(get_mailer),  # Injected
):
    mailer.send("user@example.com", "Order confirmed", "Thanks!")
    return {"ok": True}

@app.post("/invoices/{id}/send")
async def send_invoice(
    id: str,
    mailer: EmailClient = Depends(get_mailer),  # Same dependency
):
    mailer.send("user@example.com", "Your invoice", "PDF attached")
    return {"ok": True}
```

**Testing with DI**:
```python
# Override dependency for testing
def get_fake_mailer():
    return FakeEmailClient()  # No real SMTP connection

app.dependency_overrides[get_mailer] = get_fake_mailer

# Tests now use fake mailer automatically
client.post("/orders/123/confirm")  # Uses FakeEmailClient
```

**Project Implementation** (`src/services/file_service.py:224-226`):

```python
def get_file_service() -> FileService:
    """Get file service instance."""
    return FileService()

# Used in routes via Depends()
@app.post("/api/v1/transcribe")
async def transcribe_audio(
    file_service: FileService = Depends(get_file_service),  # Injected
    whisper_service: WhisperModelService = Depends(get_whisper_service),
    db: Session = Depends(get_db),
):
    # Services are provided by FastAPI, not instantiated here
    service = TranscriptionService(db, file_service, whisper_service)
    return await service.process_transcription(file)
```

**Why factory functions even without constructor args?**

Even if `FileService()` takes no arguments, the factory still helps:
- **DI hook**: FastAPI needs a callable for `Depends()`
- **Future-proofing**: Can add config/pooling later without touching routes
- **Testing**: Override `get_file_service()` to return mocks
- **Consistency**: All services use same pattern

**Further Reading**:
- [FastAPI Dependencies Tutorial](https://fastapi.tiangolo.com/tutorial/dependencies/)
- [Dependency Injection Explained (Video)](https://www.youtube.com/watch?v=f270BoTicMA)

---

## 3. Security Architecture

### 3.1 Multi-Layer Validation Strategy

**Defense-in-Depth Approach**: Multiple independent validation layers so one failure doesn't compromise security.

**Three Validation Layers** (`src/services/file_service.py:32-50`):

```python
def validate_file(self, file: UploadFile) -> None:
    """Validate uploaded file with multiple checks."""
    # Layer 1: Extension validation
    self._validate_extension(file.filename)

    # Layer 2: Size validation (chunked reading)
    self._validate_file_size(file)

    # Layer 3: MIME type validation (libmagic inspection)
    self._validate_mime_type(file)
```

#### Layer 1: Extension Validation
```python
# src/services/file_service.py:52-61
def _validate_extension(self, filename: str) -> None:
    """Validate file extension."""
    ext = Path(filename).suffix.lower()
    allowed = self._settings.allowed_extensions_list  # [".mp3"]

    if ext not in allowed:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Allowed: {', '.join(allowed)}"
        )
```

**Why not sufficient alone?** User can rename `malware.exe` to `malware.mp3`.

#### Layer 2: Size Validation
```python
# src/services/file_service.py:63-77
def _validate_file_size(self, file: UploadFile) -> None:
    """Validate file size using chunked reading."""
    max_size = self._settings.max_upload_size_bytes  # 25MB

    # Efficient size check using file.seek
    file.file.seek(0, os.SEEK_END)  # Jump to end
    total_size = file.file.tell()    # Get position (size)
    file.file.seek(0)                # Reset to start

    if total_size > max_size:
        raise HTTPException(status_code=413, detail="File too large")
```

**Why important?** Prevents:
- Memory exhaustion attacks
- Disk space exhaustion
- Slow loris-style attacks with huge uploads

#### Layer 3: MIME Type Validation (Magic Bytes)
```python
# src/services/file_service.py:79-92
def _validate_mime_type(self, file: UploadFile) -> None:
    """Validate MIME type using python-magic (libmagic)."""
    # Read first 2048 bytes for magic byte detection
    header = file.file.read(2048)
    file.file.seek(0)  # Reset pointer

    mime_type = magic.from_buffer(header, mime=True)

    if mime_type not in ALLOWED_MIME_TYPES:  # {"audio/mpeg", "audio/mp3"}
        raise HTTPException(status_code=400, detail="Invalid audio format")
```

<details>
<summary><strong>What is MIME Type Validation?</strong></summary>

**MIME (Multipurpose Internet Mail Extensions)**: Standard format for labeling digital content types.

- Format: `type/subtype` (e.g., `audio/mpeg`, `text/html`, `image/png`)
- Used in HTTP `Content-Type` headers
- Tells clients how to handle payloads

**python-magic**: Python wrapper around Unix `libmagic` utility that inspects file headers (magic bytes) to determine actual file type, regardless of extension.

**Example Magic Bytes**:
- MP3: `FF FB` or `ID3`
- PNG: `89 50 4E 47`
- PDF: `25 50 44 46`

**Why "audio/mpeg" and "audio/mp3"?**
- `audio/mpeg` is the official IANA-registered MIME type
- `audio/mp3` is non-standard but common (old IIS servers, some tools)
- Allow both to avoid rejecting valid MP3 uploads

**IANA (Internet Assigned Numbers Authority)**: Global coordinator that maintains official MIME type registry to keep names consistent across the internet.
</details>

**Why all three layers?**

| Layer | Protects Against | Weakness |
|-------|-----------------|----------|
| Extension | Accidental wrong file type | Easy to bypass (rename file) |
| Size | Memory/disk exhaustion | Doesn't check content |
| MIME | Malicious files disguised as MP3 | Can't catch all malware |

**Combined**: High confidence file is actually MP3 and safe size.

### 3.2 Filename Sanitization (Path Traversal Prevention)

**Attack Vector**: User controls filename, could inject path traversal to overwrite system files.

**Malicious Examples**:
```python
# Unix path traversal
"../../../etc/passwd"         # Try to overwrite system password file
"/etc/shadow"                 # Absolute path to sensitive file

# Windows path traversal
"..\\..\\windows\\system32\\config\\sam"  # Windows password hashes

# Null byte injection (historical)
"evil.php\x00.mp3"            # PHP executes as .php, ignores after \x00

# Special characters / injection
"test;rm -rf /.mp3"           # Command injection in shell
"file'OR'1'='1.mp3"           # SQL injection attempt
```

**Sanitization Function** (`src/services/file_service.py:94-131`):

```python
def sanitize_filename(self, filename: str) -> str:
    """Sanitize filename to prevent path traversal and injection attacks."""

    # Step 1: Remove directory path components
    filename = os.path.basename(filename)  # "../../evil" → "evil"

    # Step 2: Remove null bytes
    safe_name = filename.replace("\x00", "")

    # Step 3: Remove path traversal patterns
    safe_name = safe_name.replace("..", "").replace("/", "").replace("\\", "")

    # Step 4: Keep only safe characters (alphanumeric, dash, underscore, period)
    safe_name = re.sub(r"[^a-zA-Z0-9._-]", "_", safe_name)

    # Step 5: Collapse multiple underscores
    safe_name = re.sub(r"_+", "_", safe_name)

    # Step 6: Remove leading/trailing underscores and periods
    safe_name = safe_name.strip("_.")

    # Step 7: Ensure not empty
    if not safe_name:
        safe_name = "unnamed"

    # Step 8: Force .mp3 extension
    if not safe_name.lower().endswith(".mp3"):
        safe_name = safe_name + ".mp3"

    return safe_name
```

**Sanitization Examples**:

| Input | Output | Why |
|-------|--------|-----|
| `../../etc/passwd` | `etcpasswd.mp3` | Path traversal removed |
| `evil.php\x00.mp3` | `evil.php.mp3` | Null byte removed |
| `test;rm -rf /.mp3` | `test_rm_-rf_.mp3` | Special chars replaced |
| `<script>alert()</script>.mp3` | `_script_alert___script_.mp3` | HTML chars removed |
| `файл.mp3` | `_____.mp3` | Non-ASCII replaced with `_` |
| `""` (empty) | `unnamed.mp3` | Fallback name |

**Why not sanitize for SQL injection here?**

Filename sanitization focuses on **filesystem safety** (path traversal, weird characters). SQL injection is a **database concern** handled by:
1. **ORM parameterization** (primary defense) - SQLAlchemy never concatenates user input into SQL
2. **`sanitize_search_query()`** (defense-in-depth) - Extra layer for search queries

Keep concerns separated: filesystem safety in file service, SQL safety in database layer.

### 3.3 Search Query Sanitization (SQL Injection Prevention)

**Primary Defense**: SQLAlchemy ORM uses parameterized queries, which prevents SQL injection by design.

**Defense-in-Depth**: `sanitize_search_query()` provides an additional layer.

#### SQL Injection Example

<details>
<summary><strong>What is SQL Injection?</strong></summary>

An attack where malicious SQL code is injected into application queries through user input.

**Vulnerable Code** (string concatenation):
```python
# NEVER DO THIS - VULNERABLE
query = f"SELECT * FROM users WHERE name = '{user_input}'"
```

**Attack**:
```python
user_input = "Harrington'; DROP TABLE transcriptions; --"

# Assembled SQL becomes:
"SELECT * FROM users WHERE name = 'Harrington'; DROP TABLE transcriptions; --'"
#                                              ↑ Ends string
#                                                 ↑ Malicious command
#                                                                        ↑ Comment out rest
```

**Effect**: The injected quote ends the string, `DROP TABLE` deletes data, `--` comments out the trailing quote so SQL parses successfully.
</details>

#### How SQLAlchemy Prevents SQL Injection

```python
# SAFE - ORM parameterization
stmt = select(Transcription).where(
    Transcription.audio_filename.contains(filename_query)
)
results = db.execute(stmt).scalars().all()

# SQLAlchemy generates parameterized query:
# SELECT * FROM transcriptions WHERE audio_filename LIKE ?
# Parameters: ["%user_input%"]

# User input is passed as PARAMETER, never concatenated into SQL string
```

**Parameterization**: User input sent separately from SQL command, so it's always treated as data, never as code.

#### Sanitization Function (Defense-in-Depth)

```python
# src/utils/security.py:6-21
import re2 as re  # Google RE2 for ReDoS protection

def sanitize_search_query(query: str) -> str:
    """Sanitize search query to prevent injection attacks."""
    # Remove dangerous characters: < > " ' ; ( ) { } \
    sanitized = re.sub(r"[<>\"';(){}\\]", "", query)

    # Trim whitespace and limit length
    sanitized = sanitized.strip()[:255]

    return sanitized
```

**Why Google RE2?**

Regular Python `re` module is vulnerable to **ReDoS (Regular Expression Denial of Service)**:

```python
# Malicious input can cause exponential backtracking
import re
pattern = r"(a+)+"
text = "a" * 50 + "!"  # Takes seconds to process (exponential time)
re.search(pattern, text)  # SLOW
```

**RE2**: Google's regex engine guarantees **linear time** complexity - no backtracking, no exponential blowup.

**What Characters are Blocked and Why**:

| Character | Attack Type | Example |
|-----------|-------------|---------|
| `'` `"` | SQL injection, HTML attributes | `admin' OR '1'='1` |
| `;` | SQL/command injection | `test; DROP TABLE users` |
| `<` `>` | XSS (script tags) | `<script>alert('xss')</script>` |
| `(` `)` | Function calls, SQL | `alert('xss')`, `UNION(SELECT...)` |
| `{` `}` | Template injection | `{{7*7}}` in SSTI |
| `\` | Escape sequences | `\'` to break out of quotes |

**Attack Examples with Sanitization**:

**SQL Injection**:
```python
query = "admin' OR '1'='1' --"
sanitized = "admin OR 1=1 --"  # Quotes/semicolon removed, now inert
```

**XSS (Cross-Site Scripting)**:
```python
query = "<script>alert('XSS')</script>"
sanitized = "scriptalertXSS/script"  # < > ' removed, just text
```

**Command Injection**:
```python
query = "Harrington; rm -rf /"
sanitized = "Harrington rm -rf /"  # Semicolon removed, can't chain commands
```

**Why Not Block More Characters?**

- Blocks only **high-risk** characters for injection attacks
- Preserves **legitimate search** (spaces, numbers, letters, hyphens)
- Length limit (255 chars) prevents memory exhaustion
- Path traversal (`/`, `..`) handled by `sanitize_filename()`, not here

**Test Coverage** (`tests/unit/test_security.py`): 100+ test cases covering:
- SQL injection patterns (DROP, UNION, OR bypass)
- XSS patterns (script, img onerror, iframe)
- Command injection (semicolons, pipes)
- Edge cases (empty, whitespace, unicode, emoji)
- Length limits

### 3.4 Additional Security Measures

**Rate Limiting** (`src/main.py:32-33,103`):
```python
limiter = Limiter(key_func=get_remote_address)  # IP-based

@app.post("/api/v1/transcribe")
@limiter.limit(lambda: settings.transcribe_rate_limit)  # "5/minute"
async def transcribe_audio(...):
    ...
```

**Why?** Prevents:
- API abuse (resource exhaustion)
- Brute force attacks
- Cost escalation (if using paid ML APIs)

**CORS (Cross-Origin Resource Sharing)** (`src/main.py:63-68`):
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,  # ["http://localhost:5173"]
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

**Why?** Browser security feature that prevents malicious websites from making unauthorized API requests on behalf of users.

**Assessment**: `["http://localhost:5173"]` (frontend dev server)
**Production**: Whitelist only production domain (e.g., `["https://app.example.com"]`)

---

## 4. Database & Data Layer

### 4.1 SQLAlchemy 2.0 Architecture

<details>
<summary><strong>What is an ORM?</strong></summary>

**ORM (Object-Relational Mapping)**: Translates between Python objects and database tables. You work with Python classes/objects, ORM generates SQL automatically.

**Without ORM** (raw SQL):
```python
cursor.execute("INSERT INTO transcriptions (filename, text) VALUES (?, ?)",
               (filename, text))
conn.commit()
```

**With ORM** (Python objects):
```python
transcription = Transcription(audio_filename=filename, transcribed_text=text)
db.add(transcription)
db.commit()
```
</details>

#### Engine: Database Connector + Connection Pool

```python
# src/utils/db.py:20-24
engine = create_engine(
    settings.database_url,  # "sqlite:///data/transcriptions.db"
    connect_args={"check_same_thread": False},  # SQLite threading
    echo=settings.debug,  # Log all SQL queries in debug mode
)
```

**What is an Engine?**

The engine is the **database connector** plus **connection management**:

- **Connection Factory**: Creates database connections on demand
- **Connection Pooling**: Reuses connections to avoid overhead of reconnecting
- **Dialect**: Adapts SQL for specific database (SQLite vs PostgreSQL vs MySQL)

**Why `check_same_thread=False`?**

SQLite normally restricts connections to the thread that created them. FastAPI uses async/thread pools, so we need to disable this restriction. In production with PostgreSQL, this isn't needed.

#### Session: Transaction Workspace

```python
# src/utils/db.py:26
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db() -> Generator[Session, None, None]:
    """Dependency to get database session."""
    db = SessionLocal()
    try:
        yield db  # Route handler uses session
    finally:
        db.close()  # Always close, even on error
```

**What is a Session?**

A **short-lived workspace** that:

1. **Uses the engine** to talk to the database
2. **Tracks ORM objects** you load or change (identity map)
3. **Wraps operations in a transaction** (all succeed or all fail)
4. **Finalizes on commit()** or discards on rollback()

**Session Workflow**:

```python
# 1. Query - session tracks loaded objects
transcription = db.execute(
    select(Transcription).where(Transcription.id == 1)
).scalar_one()

# 2. Modify - session notices change (identity map)
transcription.transcribed_text = "Updated text"

# 3. Commit - send SQL to database, make permanent
db.commit()

# OR Rollback - discard changes, undo transaction
db.rollback()
```

**Identity Map**: Session maintains a Python instance for each database row. If you query the same row twice, you get the same Python object (not a duplicate).

**Transaction Wrapper**: All changes live inside one transaction:
- **Commit**: All changes succeed together
- **Rollback**: All changes fail together
- **ACID properties**: Atomic, Consistent, Isolated, Durable

#### Model Definition (SQLAlchemy 2.0 Type-Safe Style)

```python
# src/utils/db.py:54-68
class Transcription(Base):
    """Transcription database model."""

    __tablename__ = "transcriptions"

    # Type-safe column definitions with Mapped[T]
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)

    audio_filename: Mapped[str] = mapped_column(
        String(255), nullable=False, unique=True
    )

    transcribed_text: Mapped[str] = mapped_column(Text, nullable=False)

    created_timestamp: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc), nullable=False
    )
```

**Why `Mapped[T]` instead of just `Column()`?**

SQLAlchemy 2.0 adds **type safety**:
- `Mapped[int]` tells type checkers (mypy) that `transcription.id` is an `int`
- Catches type errors at development time, not runtime
- Better IDE autocomplete

### 4.2 ORM Benefits vs Raw SQL

| Feature | ORM (SQLAlchemy) | Raw SQL |
|---------|------------------|---------|
| **SQL Injection** | ✅ Parameterized by default | ❌ Manual escaping, error-prone |
| **Type Safety** | ✅ `Mapped[T]` for mypy | ❌ No type checking |
| **Refactoring** | ✅ Change column name once | ❌ Update all SQL strings |
| **Dialects** | ✅ Switch SQLite→PostgreSQL easily | ❌ Rewrite SQL syntax |
| **Relationships** | ✅ Auto-load related objects | ❌ Manual JOIN queries |
| **Performance** | ⚠️ Slight overhead | ✅ Raw speed |

**When to use Raw SQL?**

- Complex analytical queries with CTEs, window functions
- Bulk operations (thousands of rows)
- Database-specific features (PostgreSQL full-text search)

For CRUD operations and normal queries, ORM is safer and cleaner.

### 4.3 Repository Pattern Implementation

See **Section 2.2** for full explanation.

```python
# src/utils/db.py:78-111
class TranscriptionRepository:
    """Repository for transcription CRUD operations."""

    def create(self, audio_filename: str, transcribed_text: str) -> Transcription:
        """Create new transcription record."""
        transcription = Transcription(
            audio_filename=audio_filename,
            transcribed_text=transcribed_text,
        )
        self._db.add(transcription)
        self._db.commit()
        self._db.refresh(transcription)  # Load generated ID
        return transcription

    def get_all(self) -> Sequence[Transcription]:
        """Get all transcriptions, ordered by most recent first."""
        stmt = select(Transcription).order_by(
            Transcription.created_timestamp.desc()
        )
        return self._db.execute(stmt).scalars().all()

    def search_by_filename(self, filename_query: str) -> Sequence[Transcription]:
        """Search transcriptions by filename (partial match)."""
        stmt = (
            select(Transcription)
            .where(Transcription.audio_filename.contains(filename_query))
            .order_by(Transcription.created_timestamp.desc())
        )
        return self._db.execute(stmt).scalars().all()
```

**Why `db.refresh()`?**

After `commit()`, the database generates values (auto-increment ID, default timestamps). `refresh()` reloads the object from the database so Python has the latest values.

---

## 5. ML Model Integration

### 5.1 Model Selection

**Whisper Tiny**:
- Size: ~150MB (vs ~1GB for Base, ~3GB for Large)
- Accuracy: Good for clear speech (trade-off for assessment)
- Speed: Fast inference on CPU/MPS

**Why Tiny for Assessment?**
- Fast downloads/setup
- Runs on laptop CPU without GPU
- Good enough for demonstration

**Production Consideration**: Use Whisper Base or Medium for better accuracy, or Large-V3 for multilingual/noisy audio.

### 5.2 Device Selection (CUDA → MPS → CPU)

```python
# src/services/whisper_service.py:51-64
def _setup_device(self) -> str:
    """Select best available device: CUDA -> MPS -> CPU."""
    if torch.cuda.is_available():
        device = "cuda"  # NVIDIA GPU
        logger.info("Using CUDA device")
    elif torch.backends.mps.is_available():
        os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"  # Enable CPU fallback
        device = "mps"  # Apple Silicon GPU
        logger.info("Using MPS device (Apple Silicon)")
    else:
        device = "cpu"  # CPU fallback
        logger.info("Using CPU device")
    return device
```

**Device Priority**:
1. **CUDA (NVIDIA GPU)**: Fastest, production-grade (10-100x faster than CPU)
2. **MPS (Apple Silicon GPU)**: Fast on M1/M2/M3 Macs (5-20x faster than CPU)
3. **CPU**: Slowest, but universal fallback

**Why `PYTORCH_ENABLE_MPS_FALLBACK`?**

Some PyTorch operations aren't implemented for MPS. This environment variable tells PyTorch to automatically fall back to CPU for those operations instead of crashing.

**Production Performance**:
- **CPU**: ~10-30s for 1-minute audio
- **MPS (M3 Max)**: ~2-5s for 1-minute audio
- **CUDA (A100 GPU)**: ~0.5-1s for 1-minute audio

### 5.3 Model Caching

```python
# src/services/whisper_service.py:66-82
def _load_model(self) -> Any:
    """Load Whisper pipeline with caching."""
    cache_dir = Path(self._settings.model_cache_dir)  # ".cache/whisper"
    cache_dir.mkdir(parents=True, exist_ok=True)

    pipe = pipeline(
        "automatic-speech-recognition",
        model=self._settings.whisper_model_name,  # "openai/whisper-tiny"
        device=self._device,
        model_kwargs={"cache_dir": str(cache_dir)},
    )

    return pipe
```

**Why Cache?**

First run:
1. Download model from HuggingFace (~150MB)
2. Load into memory (~5-10s)
3. **Total**: ~30s+ depending on network

Subsequent runs:
1. Load from cache (~5-10s)
2. **Total**: ~5-10s

**Cache Location**: `.cache/whisper/` (configurable in settings)

### 5.4 Transcription with Chunked Processing

```python
# src/services/whisper_service.py:94-120
def transcribe(self, audio_path: str | Path) -> str:
    """Transcribe audio file and return text."""
    if not self.is_loaded:
        raise RuntimeError("Whisper model not loaded")

    result = self._pipeline(
        str(audio_path),
        chunk_length_s=self._settings.whisper_chunk_length_s,  # 30 seconds
        stride_length_s=self._settings.whisper_stride_length_s,  # 5 seconds
    )

    text = result.get("text", "").strip()
    return text
```

**Why Chunked Processing?**

Long audio files (10+ minutes) can:
- Exceed model context window
- Cause memory exhaustion
- Degrade accuracy (attention mechanism weakens over long sequences)

**Chunking Strategy**:
- `chunk_length_s=30`: Process 30-second segments
- `stride_length_s=5`: Overlap segments by 5 seconds to avoid cutting words

**Example**: 2-minute audio
- Chunk 1: 0-30s
- Chunk 2: 25-55s (5s overlap with chunk 1)
- Chunk 3: 50-80s (5s overlap with chunk 2)
- Chunk 4: 75-105s
- Chunk 5: 100-120s

Overlapping prevents cutting words at chunk boundaries.

### 5.5 Lifespan Management (Model Preloading)

```python
# src/main.py:36-50
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup and shutdown."""
    # Startup: Load model before accepting requests
    logger.info("Starting application...")
    init_db()  # Create database tables

    whisper = get_whisper_service()  # Singleton loads model
    logger.info(f"Whisper model loaded on device: {whisper.device}")

    yield  # App serves requests

    # Shutdown: Cleanup (if needed)
    logger.info("Shutting down application...")

app = FastAPI(lifespan=lifespan)
```

**Why Preload on Startup?**

**Without preloading**:
- First user request triggers model loading (10s delay)
- Bad user experience

**With preloading**:
- Model loads during app startup (once)
- First request is fast (<1s)
- All requests benefit from cached model

**Lifespan Hook**: FastAPI feature to run code before/after app serves requests.

---

## 6. API Design & FastAPI Features

### 6.1 API Endpoints

**Base URL**: `http://localhost:8000`

#### 1. Health Check
```http
GET /api/v1/health
```

**Response** (Enhanced - checks all dependencies):
```json
{
  "status": "healthy",
  "timestamp": "2026-01-29T10:30:00Z",
  "model_loaded": true,
  "device_info": "mps",
  "db_healthy": true,
  "redis_healthy": true,
  "celery_workers_active": true
}
```

**Purpose**: Comprehensive health check that verifies all critical dependencies:
- **model_loaded**: Whisper model singleton is loaded
- **db_healthy**: Database connection is active (runs `SELECT 1`)
- **redis_healthy**: Redis broker connection is working (`PING` command)
- **celery_workers_active**: At least one Celery worker is running (inspects worker stats)
- **status**: Returns `"healthy"` only if ALL checks pass, otherwise `"degraded"`

**Why check all dependencies?**
- Load balancers need to know if service can actually process requests
- A server with broken DB/Redis/Celery cannot fulfill transcription requests
- Prevents routing traffic to degraded instances
- Enables automated alerts when dependencies fail

**Implementation**:
```python
@app.get("/api/v1/health")
async def health_check(
    whisper: WhisperModelService = Depends(get_whisper_service),
    db: Session = Depends(get_db),
):
    # Check Whisper model
    model_healthy = whisper.is_loaded

    # Check database
    db_healthy = False
    try:
        db.execute(text("SELECT 1"))
        db_healthy = True
    except Exception as e:
        logger.error(f"Database health check failed: {e}")

    # Check Redis broker
    redis_healthy = False
    try:
        celery.broker_connection().ensure_connection(max_retries=1)
        redis_healthy = True
    except Exception as e:
        logger.error(f"Redis health check failed: {e}")

    # Check Celery workers
    celery_workers_healthy = False
    try:
        stats = celery.control.inspect().stats()
        celery_workers_healthy = stats is not None and len(stats) > 0
    except Exception as e:
        logger.error(f"Celery worker health check failed: {e}")

    all_healthy = all([model_healthy, db_healthy, redis_healthy, celery_workers_healthy])

    return HealthResponse(
        status="healthy" if all_healthy else "degraded",
        timestamp=datetime.now(timezone.utc),
        model_loaded=model_healthy,
        device_info=whisper.device,
        db_healthy=db_healthy,
        redis_healthy=redis_healthy,
        celery_workers_active=celery_workers_healthy,
    )
```

#### 2. Transcribe Audio
```http
POST /api/v1/transcribe
Content-Type: multipart/form-data

file: [MP3 file binary]
```

**Response** (201 Created):
```json
{
  "id": 1,
  "audio_filename": "sample_20260129_103000_a3f2b1c4.mp3",
  "transcribed_text": "Hello, this is a test transcription.",
  "created_timestamp": "2026-01-29T10:30:00Z"
}
```

**Error Responses**:
- `400`: Invalid file type/format
- `413`: File too large (>25MB)
- `429`: Rate limit exceeded (5 requests/minute)
- `500`: Transcription failed

**Rate Limited**: 5 requests per minute per IP address.

#### 3. List Transcriptions
```http
GET /api/v1/transcriptions
```

**Response**:
```json
[
  {
    "id": 2,
    "audio_filename": "sample2_20260129_103100_b4c3d2e5.mp3",
    "transcribed_text": "...",
    "created_timestamp": "2026-01-29T10:31:00Z"
  },
  {
    "id": 1,
    "audio_filename": "sample_20260129_103000_a3f2b1c4.mp3",
    "transcribed_text": "...",
    "created_timestamp": "2026-01-29T10:30:00Z"
  }
]
```

**Ordering**: Most recent first (`ORDER BY created_timestamp DESC`).

#### 4. Search Transcriptions
```http
GET /api/v1/search?filename=sample
```

**Response**:
```json
{
  "query": "sample",
  "results": [
    {
      "id": 1,
      "audio_filename": "sample_20260129_103000_a3f2b1c4.mp3",
      "transcribed_text": "...",
      "created_timestamp": "2026-01-29T10:30:00Z"
    }
  ]
}
```

**Search**: Partial filename match (case-sensitive `LIKE` in SQLite).

**Sanitization**: Query sanitized with `sanitize_search_query()` before database search.

### 6.2 Rate Limiting (slowapi)

```python
# src/main.py:32-33
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)  # IP-based rate limiting

# Attach to app
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Apply to endpoint
@app.post("/api/v1/transcribe")
@limiter.limit(lambda: settings.transcribe_rate_limit)  # "5/minute"
async def transcribe_audio(...):
    ...
```

**How It Works**:
1. Extract client IP address (`get_remote_address`)
2. Track requests per IP in memory (or Redis for distributed)
3. Reject requests exceeding limit with `429 Too Many Requests`

**Configuration** (`settings.py`):
```python
transcribe_rate_limit: str = "5/minute"  # 5 requests per minute per IP
```

**Production Considerations**:
- Use Redis backend for multi-instance deployments
- Per-user rate limits (not just IP) with authentication
- Different limits for different tiers (free vs paid)

### 6.3 CORS Middleware

```python
# src/main.py:63-68
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,  # ["http://localhost:5173"]
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
```

<details>
<summary><strong>What is CORS?</strong></summary>

**CORS (Cross-Origin Resource Sharing)**: Browser security feature that blocks JavaScript from one domain making requests to another domain.

**Example**:
- Frontend: `http://localhost:5173` (React dev server)
- Backend: `http://localhost:8000` (FastAPI)

Without CORS, browser blocks requests from frontend to backend (different ports = different origins).

**Solution**: Backend explicitly allows frontend origin via CORS headers.
</details>

**Assessment**: Allow `http://localhost:5173` for local development.

**Production**: Whitelist only production domain:
```python
allow_origins=["https://app.example.com"]
```

**Why Not `allow_origins=["*"]`?**

Wildcard allows ANY website to call your API, enabling:
- CSRF attacks
- Data theft
- API abuse

Always whitelist specific domains in production.

### 6.4 Pydantic Response Models

```python
# src/utils/schemas.py
from pydantic import BaseModel

class TranscriptionResponse(BaseModel):
    """Response model for transcription."""
    id: int
    audio_filename: str
    transcribed_text: str
    created_timestamp: datetime
```

**Benefits**:
1. **Type Safety**: Catches type errors at runtime
2. **Validation**: Ensures all required fields present
3. **Documentation**: Auto-generates OpenAPI schema (Swagger docs)
4. **Serialization**: Converts SQLAlchemy models to JSON automatically

**Usage**:
```python
@app.post("/api/v1/transcribe", response_model=TranscriptionResponse)
async def transcribe_audio(...) -> TranscriptionResponse:
    # FastAPI serializes transcription object to JSON using schema
    return TranscriptionResponse(
        id=transcription.id,
        audio_filename=transcription.audio_filename,
        transcribed_text=transcription.transcribed_text,
        created_timestamp=transcription.created_timestamp,
    )
```

### 6.5 Automatic API Documentation (Swagger/OpenAPI)

FastAPI auto-generates interactive API docs:

- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

**Features**:
- Try API endpoints in browser
- See request/response schemas
- View error codes and descriptions
- Download OpenAPI spec for client generation

---

## 7. Async I/O & Performance

### 7.1 Async File Upload (Chunked Reading)

```python
# src/services/file_service.py:153-191
async def save_file(self, file: UploadFile) -> tuple[str, Path]:
    """Save uploaded file securely with chunked reading."""
    unique_filename = self.generate_unique_filename(file.filename)
    file_path = self._upload_dir / unique_filename

    try:
        # Save in small chunks (64KB) to minimize memory usage
        with open(file_path, "wb") as buffer:
            while chunk := await file.read(CHUNK_SIZE):  # 64KB chunks
                buffer.write(chunk)

        return unique_filename, file_path

    except Exception as e:
        if file_path.exists():
            file_path.unlink()  # Delete partial file
        raise
```

**Why Chunked Reading?**

**Without chunking**:
```python
# Loads entire 25MB file into memory
content = await file.read()  # 25MB memory usage
with open(file_path, "wb") as f:
    f.write(content)
```

**With chunking**:
```python
# Loads 64KB at a time
while chunk := await file.read(64 * 1024):  # 64KB memory usage
    buffer.write(chunk)
```

**Benefits**:
- **Memory Efficiency**: 64KB vs 25MB per upload
- **Scalability**: Handle 100 concurrent uploads with low memory
- **Resilience**: Partial failure cleanup (delete incomplete file)

### 7.2 Walrus Operator (`:=`)

<details>
<summary><strong>What is the Walrus Operator?</strong></summary>

**Walrus operator (`:=`)**: Assignment expression added in Python 3.8. Assigns a value to a variable **and** returns that value in one expression.
</details>

**Without Walrus**:
```python
chunk = await file.read(CHUNK_SIZE)
while chunk:
    buffer.write(chunk)
    chunk = await file.read(CHUNK_SIZE)  # Duplicate read call
```

**With Walrus**:
```python
while chunk := await file.read(CHUNK_SIZE):  # Assign + check
    buffer.write(chunk)
```

**How It Works**:
1. `await file.read(CHUNK_SIZE)` reads chunk
2. `:=` assigns to `chunk` variable
3. Expression evaluates to the assigned value
4. `while` checks if value is truthy (non-empty bytes)

**When to Use**:
- Reduce code duplication
- Combine assignment + condition
- Make loops more concise

**Readability Trade-off**: Some find `:=` less clear than explicit assignment. Use judiciously.

### 7.3 File Buffering

```python
with open(file_path, "wb") as buffer:
    while chunk := await file.read(CHUNK_SIZE):
        buffer.write(chunk)
```

**Variable Name "buffer"**: Hints that the file handle is buffering writes.

<details>
<summary><strong>What is File Buffering?</strong></summary>

**Buffering**: Operating system optimization where small writes are accumulated in memory before being flushed to disk.

**Why?** Disk I/O is slow (~100x slower than memory). Buffering reduces syscalls.

**Example**:
```python
# Without buffering - 1000 syscalls
for i in range(1000):
    os.write(fd, b"x")  # 1000 slow disk writes

# With buffering - ~10 syscalls
f = open("file", "wb")  # Buffered by default
for i in range(1000):
    f.write(b"x")  # Writes to memory buffer
# Buffer flushed to disk automatically when full or on close
```

**Default Buffer Size**: 8KB on Linux, 4KB on Windows.

**Manual Flush**: `f.flush()` forces immediate disk write.
</details>

### 7.4 Unique Filename Generation

```python
# src/services/file_service.py:133-151
def generate_unique_filename(self, original_filename: str) -> str:
    """Generate unique filename with timestamp and random suffix.

    Format: {name}_{timestamp}_{random}.mp3
    """
    sanitized = self.sanitize_filename(original_filename)
    stem = Path(sanitized).stem  # Filename without extension
    suffix = Path(sanitized).suffix  # Extension (.mp3)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    random_suffix = token_hex(4)  # 8 hex chars (4 bytes)

    return f"{stem}_{timestamp}_{random_suffix}{suffix}"
```

**Example**:
```python
original: "my recording.mp3"
sanitized: "my_recording.mp3"
stem: "my_recording"
suffix: ".mp3"

timestamp: "20260129_103045"
random_suffix: "a3f2b1c4"  # Cryptographically secure random

unique: "my_recording_20260129_103045_a3f2b1c4.mp3"
```

**Why Unique Filenames?**

**Problem**: User uploads `sample.mp3` multiple times
- Without uniqueness: Each upload overwrites previous
- With uniqueness: Each upload gets distinct filename

**Collision Resistance**:
- Timestamp: Second precision (~3600 collisions/hour possible)
- Random suffix: 8 hex chars = 4.3 billion possibilities
- **Combined**: Virtually zero collision probability

**Security**: `token_hex()` uses cryptographically secure randomness (not `random.randint()`), preventing prediction attacks.

---

## 8. Background Task Processing (Celery + Redis)

### 8.1 The Problem: Long-Running Tasks Block HTTP Requests

**Synchronous (Blocking) Architecture** - What we DON'T want:

```python
# Synchronous endpoint - BLOCKS for 30-60 seconds
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile):
    save_file(file)                      # Fast: ~100ms
    text = whisper.transcribe(file)      # SLOW: 30-60 seconds ⏳
    db.save(text)                        # Fast: ~10ms
    return {"text": text}                # User waits 60+ seconds!
```

**Problems**:
- 🔴 **Request Timeout**: HTTP requests timeout after 30-60 seconds
- 🔴 **Server Blocked**: Can't handle other requests while transcribing
- 🔴 **Poor UX**: User stares at loading spinner for a minute
- 🔴 **No Scalability**: 1 request at a time = 60 requests/hour max

**Asynchronous (Non-Blocking) Architecture** - What we WANT:

```python
# Async endpoint - Returns immediately
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile):
    save_file(file)                           # Fast: ~100ms
    db.create(status="processing")            # Fast: ~10ms
    task = transcribe_task.delay(file_path)   # Queue task, return immediately
    return {"task_id": task.id, "status": "processing"}  # User gets response in 200ms!

# Background worker processes task separately
@celery.task
def transcribe_task(file_path):
    text = whisper.transcribe(file_path)  # Runs in background
    db.update(text, status="completed")   # Update when done
```

**Benefits**:
- ✅ **Instant Response**: API returns in 200ms (not 60 seconds)
- ✅ **Non-Blocking**: Server can handle 100s of concurrent uploads
- ✅ **Better UX**: User gets task ID, polls for status
- ✅ **Scalable**: Process 1000s of files concurrently with multiple workers

---

### 8.2 What is a Message Broker? (Redis)

<details>
<summary><strong>Message Broker Fundamentals</strong></summary>

**Message Broker**: Middleware that receives messages from producers (API) and delivers them to consumers (workers).

**Key Concepts**:

1. **Queue**: Ordered list of messages (FIFO - First In, First Out)
2. **Producer**: Sends messages to queue (our FastAPI app)
3. **Consumer**: Receives messages from queue (Celery workers)
4. **Broker**: Manages queues and message delivery (Redis)

</details>

**Why Redis as Message Broker?**

Redis is an **in-memory data structure store** that can function as:
- **Message Broker**: Stores task messages in queues
- **Result Backend**: Stores task results after completion
- **Cache**: Fast key-value storage


**Message Flow**:

```
1) API endpoint (producer trigger)
   → calls task.delay(file_path, transcription_id)

2) Celery client inside FastAPI (producer)
   → serializes task (JSON/pickle/etc.)
   → LPUSH serialized message to Redis list “celery”

3) Redis (broker)
   → stores the bytes; the list “celery” itself is the queue

4) Celery worker (consumer)
   → BRPOP “celery” (“Blocking” just means the worker waits idly if the list is empty; once any producer LPUSHes a task into that queue, BRPOP instantly returns it and the worker proceeds!)
   → deserializes → runs transcribe_audio_task() --> runs our function!!!

5) Redis (result backend)
   → db.update(text, status="completed") -- text = transcribed text!  

*LPUSH = left push
*BRPOP = Blocking Right POP 
*LPUSH + BRPOP keep FIFO order
```

**Redis Commands Celery Uses**:

```bash
# Add task to queue (Producer)
LPUSH celery '{"task": "transcribe_audio", "args": ["/path/to/audio.mp3", 1]}'

# Worker fetches task (Consumer) - Blocking pop
BRPOP celery 0  # Waits indefinitely until task available

# Store task result
SET celery-task-meta-abc123 '{"status": "SUCCESS", "result": "Hello world"}'
EXPIRE celery-task-meta-abc123 3600  # Auto-delete after 1 hour

# Get task status
GET celery-task-meta-abc123
```

**Why Redis vs Other Brokers?**

| Feature | Redis | RabbitMQ | Amazon SQS |
|---------|-------|----------|------------|
| **Speed** | ⚡ In-memory (fastest) | 💾 Disk-based | ☁️ Network latency |
| **Persistence** | ⚠️ Optional (can lose data on crash) | ✅ Durable | ✅ Durable |
| **Setup** | ✅ Simple (1 command) | ⚠️ Complex (AMQP protocol) | ☁️ Managed service |
| **Use Case** | Fast, non-critical tasks | Mission-critical tasks | AWS-native apps |

**Our Choice**: Redis because:
- ✅ **Fast**: In-memory = microsecond latency
- ✅ **Simple**: No complex configuration
- ✅ **Dual Purpose**: Message broker + result backend
- ⚠️ **Trade-off**: If Redis crashes, pending tasks are lost (acceptable for transcription - user can re-upload)

---

### 8.3 What is Celery? (Distributed Task Queue)

**Celery**: Python library for running tasks asynchronously in background workers.

**Core Components**:

```
┌─────────────────────────────────────────────────────────────────┐
│                     Celery Architecture                          │
└─────────────────────────────────────────────────────────────────┘

┌──────────────┐         ┌──────────────┐         ┌──────────────┐
│   FastAPI    │         │    Redis     │         │Celery Worker │
│   (Client)   │         │   (Broker)   │         │  (Consumer)  │
└──────────────┘         └──────────────┘         └──────────────┘
       │                        │                        │
       │ 1. task.delay()        │                        │
       │───────────────────────>│                        │
       │                        │                        │
       │                        │ 2. BRPOP (fetch task)  │
       │                        │<───────────────────────│
       │                        │                        │
       │                        │                        │ 3. Execute task
       │                        │                        │──────────┐
       │                        │                        │          │
       │                        │ 4. Store result        │<─────────┘
       │                        │<───────────────────────│
       │                        │                        │
       │ 5. Get status          │                        │
       │───────────────────────>│                        │
       │<───────────────────────│                        │
       │    {"status": "SUCCESS", "result": "..."}        │
```

**1. Celery Client** (FastAPI app):
- Creates tasks: `task.delay(args)`
- Sends tasks to broker (Redis)
- Retrieves task status: `AsyncResult(task_id)`

**2. Message Broker** (Redis):
- Stores task queue (list of pending tasks)
- Delivers tasks to workers
- Stores task results (after completion)

**3. Celery Worker** (Background process):
- Polls broker for new tasks
- Executes task function
- Returns result to broker

**4. Result Backend** (Redis):
- Stores task status (PENDING, STARTED, SUCCESS, FAILURE)
- Stores task return value
- Auto-expires after 1 hour (configurable)

---

### 8.4 Celery Task Lifecycle

**Task States**:

```
PENDING ──> STARTED ──> SUCCESS
    │                       │
    │                       ├──> FAILURE (exception raised)
    │                       └──> RETRY (automatic retry)
    │
    └──> REVOKED (task cancelled)
```

**Detailed Flow**:

```python
# 1. PENDING - Task created but not yet started
task = transcribe_audio_task.delay("/audio.mp3", 1)
print(task.state)  # "PENDING"

# Worker picks up task...

# 2. STARTED - Worker begins execution
# (If task_track_started=True in config)
print(task.state)  # "STARTED"

# 3. PROCESSING - Custom state (optional)
@celery.task(bind=True)
def transcribe_audio_task(self, file_path, transcription_id):
    self.update_state(state='PROCESSING', meta={'progress': 50})
    # ...

# 4. SUCCESS - Task completed normally
print(task.state)  # "SUCCESS"
print(task.result) # {"status": "completed", "text": "..."}

# 5. FAILURE - Task raised exception
print(task.state)  # "FAILURE"
print(task.info)   # Exception traceback
```

**Task Result Object**:

```python
from celery.result import AsyncResult

# Get task status
task = AsyncResult(task_id, app=celery)

# Check state
if task.state == 'PENDING':
    print("Task not started yet")
elif task.state == 'PROCESSING':
    print(f"Progress: {task.info.get('progress')}%")
elif task.state == 'SUCCESS':
    print(f"Result: {task.result}")
elif task.state == 'FAILURE':
    print(f"Error: {task.info}")  # Exception object
```

---

### 8.5 Our Celery Implementation

**File**: `backend/src/celery_app.py`

```python
from celery import Celery

# Create Celery app
celery = Celery(
    'transcription_tasks',
    broker='redis://redis:6379/0',      # Where to send tasks
    backend='redis://redis:6379/1',     # Where to store results
)

# Configuration
celery.conf.update(
    task_serializer='json',              # Serialize tasks as JSON
    accept_content=['json'],             # Only accept JSON messages
    result_serializer='json',            # Serialize results as JSON
    timezone='UTC',
    enable_utc=True,
    task_track_started=True,             # Track when task starts
    task_time_limit=3*60,                # 3 minute timeout
    worker_prefetch_multiplier=1,        # Fetch 1 task at a time
    result_expires=3600,                 # Results expire after 1 hour
)

@celery.task(bind=True, name='transcription_tasks.transcribe_audio')
def transcribe_audio_task(self, file_path: str, transcription_id: int) -> dict:
    """Background task to transcribe audio file."""
    from src.services.whisper_service import WhisperModelService
    from src.utils.db import get_db, TranscriptionRepository

    try:
        # Update progress
        self.update_state(state='PROCESSING', meta={'status': 'Loading audio'})

        # Transcribe
        whisper = WhisperModelService()
        text = whisper.transcribe(file_path)

        # Update database
        self.update_state(state='PROCESSING', meta={'status': 'Saving results'})
        db = next(get_db())
        try:
            repo = TranscriptionRepository(db)
            repo.update_transcription_text(transcription_id, text)
            repo.update_transcription_status(transcription_id, 'completed')
        finally:
            db.close()

        return {'status': 'completed', 'text': text}

    except Exception as e:
        # Update database with error
        db = next(get_db())
        try:
            repo = TranscriptionRepository(db)
            repo.update_transcription_status(transcription_id, 'failed')
            repo.update_transcription_error(transcription_id, str(e))
        finally:
            db.close()
        raise  # Re-raise for Celery to mark as FAILURE
```

**Key Configuration Explained**:

#### `worker_prefetch_multiplier=1`

**What it controls**: How many tasks each worker **fetches** from the queue (not how many run simultaneously).

**Default**: 4 (worker fetches 4 tasks at once)

**Problem with default**:
```
Worker A: Fetches 4 long tasks (30 min each) → Busy for 2 hours
Worker B: Idle (no tasks left in queue)
Worker C: Idle
```

**With `prefetch_multiplier=1`**:
```
Worker A: Fetches 1 task (30 min)
Worker B: Fetches 1 task (30 min)
Worker C: Fetches 1 task (30 min)
All workers busy → Better load balancing
```

**Trade-off**: Slightly more Redis communication (negligible for tasks >10 seconds)

---

#### `--concurrency=2` (Worker Startup Argument)

**What it controls**: Number of tasks that run **simultaneously** per worker.

**How to choose**:

```python
# CPU-bound tasks (transcription, ML inference)
concurrency = CPU_cores - 1
# Examples: 4 cores → 2, 8 cores → 4-6

# I/O-bound tasks (API calls, file downloads)
concurrency = 10-50  # Can be much higher

# GPU-bound tasks
concurrency = 1  # GPUs can't efficiently run multiple models
```

**Our Setup**:
```bash
celery -A src.celery_app worker --concurrency=2
```
- ✅ Safe for most machines (2-4 cores)
- ✅ Prevents resource exhaustion
- ✅ Can process 2 transcriptions simultaneously

**Example Execution**:
```
Worker Process (1 worker, concurrency=2):
├── Thread Pool:
│   ├── Thread 1: transcribe("audio1.mp3")  ← Running
│   └── Thread 2: transcribe("audio2.mp3")  ← Running
└── Fetches next task when thread becomes available
```

---

#### `result_expires=3600` (1 Hour Auto-Cleanup)

**What it does**: Automatically deletes task results from Redis after 1 hour.

**Why needed?**
```python
# Without expiration - Memory leak
for i in range(10000):
    task = transcribe.delay(...)  # Each result stored forever
    # Redis memory grows infinitely!

# With expiration - Auto cleanup
for i in range(10000):
    task = transcribe.delay(...)
    # Results auto-deleted after 1 hour
    # Redis memory stays constant
```

**Timeline**:
```
0:00 - Task created (PENDING)
0:05 - Task completes (SUCCESS) - Result stored in Redis
1:05 - Result expires and deleted from Redis
∞    - Database record persists forever (what users care about)
```

**Why 1 hour?**
- ✅ Plenty of time for frontend to poll status (polling every 2-3 seconds)
- ✅ Prevents Redis memory leak
- ✅ Task results are temporary (final data is in database)

---

### 8.6 Task Execution Flow (Complete Example)

**User uploads audio file**:

```
1. User uploads sample.mp3 to /api/v1/transcribe
   ↓
2. FastAPI endpoint:
   POST /api/v1/transcribe
   │
   ├─ Validate file (size, type, content)
   ├─ Save file to disk: uploads/sample_20260129_103045_a3f2.mp3
   ├─ Create DB record: transcriptions.id=1, status="processing"
   │
   └─ Queue Celery task:
      task = transcribe_audio_task.delay("/uploads/sample_...", 1)
      Return: {"task_id": "abc123", "status": "processing"}

   ⏱️ Response time: 200ms (instant!)

3. Redis (Broker):
   LPUSH celery '{"task": "transcribe_audio", "args": [...]}'

4. Celery Worker (Background):
   BRPOP celery  # Worker pulls task from queue
   │
   ├─ Load Whisper model (if not cached)
   ├─ Transcribe audio (30-60 seconds)
   ├─ Update database: transcriptions.id=1, text="...", status="completed"
   └─ Store result in Redis:
      SET celery-task-meta-abc123 '{"status": "SUCCESS", "result": {...}}'
      EXPIRE celery-task-meta-abc123 3600  # Auto-delete after 1 hour

5. User polls status:
   GET /api/v1/status/abc123
   │
   ├─ task = AsyncResult("abc123")
   ├─ Redis: GET celery-task-meta-abc123
   └─ Return: {"status": "completed", "text": "Hello world"}

6. After 1 hour:
   Redis: DEL celery-task-meta-abc123  # Auto-cleanup
   Database: Record persists forever
```

---

### 8.7 Error Handling & Retries

**Automatic Retries** (Optional):

```python
@celery.task(bind=True, autoretry_for=(Exception,), retry_kwargs={'max_retries': 3})
def transcribe_audio_task(self, file_path, transcription_id):
    try:
        text = whisper.transcribe(file_path)
        return {'text': text}
    except Exception as e:
        # Celery automatically retries up to 3 times
        raise self.retry(exc=e, countdown=60)  # Wait 60s before retry
```

**Manual Error Handling** (Our Approach):

```python
@celery.task(bind=True)
def transcribe_audio_task(self, file_path, transcription_id):
    try:
        # ... transcription logic ...
        return {'status': 'completed', 'text': text}

    except Exception as e:
        # Update database with error
        repo.update_transcription_status(transcription_id, 'failed')
        repo.update_transcription_error(transcription_id, str(e))

        # Re-raise so Celery marks task as FAILURE
        raise
```

**Why no auto-retry?**
- ✅ Transcription failures are rare (malformed audio)
- ✅ User can manually re-upload file
- ✅ Simpler debugging (no retry loops)
- ✅ Faster failure feedback

---

### 8.8 Monitoring with Flower

**Flower**: Web-based real-time monitoring tool for Celery.

**Start Flower**:
```bash
celery -A src.celery_app flower --port=5555
```

**Access**: http://localhost:5555

**Dashboard Shows**:
- 📊 **Active Workers**: How many workers are running
- 📈 **Task Stats**: Success/failure rates, avg execution time
- 🔍 **Task History**: All tasks (pending, running, completed, failed)
- 📉 **Real-Time Graphs**: Tasks per second, worker load
- 🎯 **Individual Tasks**: Click to see args, result, traceback

**Example View**:
```
┌─────────────────────────────────────────────────────┐
│ Flower Dashboard                                     │
├─────────────────────────────────────────────────────┤
│ Workers: 3 online                                    │
│ Tasks: 1,234 processed (98% success)                 │
│                                                       │
│ Active Tasks:                                        │
│ ├─ transcribe_audio (abc123) - Running (30s)        │
│ ├─ transcribe_audio (def456) - Running (45s)        │
│ └─ transcribe_audio (ghi789) - Pending              │
│                                                       │
│ Recent Completed:                                    │
│ ├─ transcribe_audio (xyz999) - SUCCESS (58s)        │
│ └─ transcribe_audio (aaa111) - FAILURE              │
└─────────────────────────────────────────────────────┘
```

---

### 8.9 Docker Compose Integration

**File**: `docker-compose.yml`

```yaml
services:
  # Redis - Message broker + result backend
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s

  # Backend API
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - CELERY_BROKER_URL=redis://redis:6379/0
      - CELERY_RESULT_BACKEND=redis://redis:6379/1
    depends_on:
      redis:
        condition: service_healthy

  # Celery Worker
  celery_worker:
    build: ./backend
    command: celery -A src.celery_app worker --loglevel=info --concurrency=2
    volumes:
      - ./backend/uploads:/app/uploads  # Shared file access
    environment:
      - CELERY_BROKER_URL=redis://redis:6379/0
      - CELERY_RESULT_BACKEND=redis://redis:6379/1
    depends_on:
      - redis
      - backend

  # Flower - Monitoring UI
  flower:
    build: ./backend
    command: celery -A src.celery_app flower --port=5555
    ports:
      - "5555:5555"
    depends_on:
      - redis
      - celery_worker
```

**Service Dependencies**:
```
Redis (healthy) → Backend API → Celery Worker → Flower
                      ↓
                  Frontend
```

**Why Shared Volumes?**
- Backend saves uploaded files to `./backend/uploads/`
- Celery worker reads files from same directory
- Both containers mount the same volume → File sharing works

---

### 8.10 Key Takeaways

**Why Async Processing?**
- ✅ **Non-Blocking**: API responds instantly, user doesn't wait
- ✅ **Scalable**: Process 100s of files concurrently
- ✅ **Resilient**: Workers can crash/restart without losing data (in database)

**Why Redis?**
- ⚡ **Fast**: In-memory data store (microsecond latency)
- 🔄 **Dual Purpose**: Message broker + result backend
- 📦 **Simple**: No complex setup (unlike RabbitMQ)

**Why Celery?**
- 🐍 **Python-Native**: Built for Python (no language interop)
- 🔧 **Feature-Rich**: Retries, schedules, chaining, monitoring
- 📊 **Flower**: Beautiful monitoring UI out-of-the-box

**Configuration Essentials**:
- `worker_prefetch_multiplier=1`: Better load balancing for long tasks
- `--concurrency=2`: Run 2 tasks simultaneously (safe for 4-core machines)
- `result_expires=3600`: Auto-delete task results after 1 hour (prevent memory leak)

**Testing Async Tasks**:
```python
# Integration test
def test_transcription_workflow(test_client):
    # Upload file
    response = client.post("/transcribe", files={"file": mp3_data})
    task_id = response.json()["task_id"]

    # Poll until complete
    for _ in range(30):  # Max 60 seconds
        status = client.get(f"/status/{task_id}").json()
        if status["status"] == "completed":
            break
        time.sleep(2)

    assert status["text"] is not None
```

---

## 9. Configuration Management

### 8.1 Settings Singleton (Pydantic BaseSettings)

```python
# src/utils/settings.py
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # App
    app_name: str = "Audio Transcription API"
    debug: bool = False

    # Database
    database_url: str = "sqlite:///data/transcriptions.db"

    # File Upload
    upload_dir: str = "data/uploads"
    max_upload_size_mb: int = 25
    allowed_extensions: str = ".mp3"

    # Whisper Model
    whisper_model_name: str = "openai/whisper-tiny"
    model_cache_dir: str = ".cache/whisper"
    whisper_chunk_length_s: int = 30
    whisper_stride_length_s: int = 5

    # API
    cors_origins: str = "http://localhost:5173"
    transcribe_rate_limit: str = "5/minute"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance (singleton)."""
    return Settings()
```

**Why Singleton for Settings?**

Settings are:
- **Immutable** after loading (no changes at runtime)
- **Expensive to validate** (Pydantic validation on each instantiation)
- **Globally needed** (used across services, routes, etc.)

**Without caching**:
```python
settings = Settings()  # Loads .env, validates every time
settings = Settings()  # Duplicate work
```

**With `@lru_cache`**:
```python
settings = get_settings()  # Loads .env once, caches
settings = get_settings()  # Returns cached instance
```

### 8.2 Environment Variables (.env)

```bash
# .env (development)
DEBUG=true
DATABASE_URL=sqlite:///data/transcriptions.db
MAX_UPLOAD_SIZE_MB=25
WHISPER_MODEL_NAME=openai/whisper-tiny
CORS_ORIGINS=http://localhost:5173
TRANSCRIBE_RATE_LIMIT=5/minute
```

**Why Environment Variables?**

**12-Factor App Principle**: Store config in environment, not code.

**Benefits**:
- Different config for dev/staging/prod without code changes
- Secrets not committed to Git
- Easy override for testing

**Pydantic Features**:
- Type validation (converts `"25"` string to `25` int)
- Default values if env var missing
- Auto-loads from `.env` file
- Error messages for invalid config

### 8.3 Derived Properties

```python
# src/utils/settings.py (properties computed from settings)
@property
def max_upload_size_bytes(self) -> int:
    """Convert MB to bytes."""
    return self.max_upload_size_mb * 1024 * 1024

@property
def allowed_extensions_list(self) -> list[str]:
    """Parse comma-separated extensions."""
    return [ext.strip() for ext in self.allowed_extensions.split(",")]

@property
def cors_origins_list(self) -> list[str]:
    """Parse comma-separated CORS origins."""
    return [origin.strip() for origin in self.cors_origins.split(",")]
```

**Why Derived Properties?**

Store human-readable config (25MB, ".mp3,.wav"), compute machine-readable values (25165824 bytes, `[".mp3", ".wav"]`).

**Example**:
```python
settings.max_upload_size_mb  # 25 (human-readable)
settings.max_upload_size_bytes  # 26214400 (for validation logic)
```

---

## 10. Testing Strategy

### 9.1 Test Coverage

**100+ Tests** across:
- **Unit Tests**: Individual functions, security sanitization
- **Integration Tests**: End-to-end API workflows

**Test Structure**:
```
tests/
├── unit/
│   ├── test_security.py          # 40+ security attack tests
│   ├── test_file_service.py      # File validation tests
│   └── test_whisper_service.py   # Model singleton tests
└── integration/
    └── test_api.py                # Full transcription workflow
```

### 9.2 Security-First Testing

**100+ Attack Pattern Tests** (`tests/unit/test_security.py`):

**SQL Injection**:
```python
def test_sql_injection_drop_table():
    """Test blocking SQL DROP TABLE injection."""
    query = "test'; DROP TABLE transcriptions; --"
    result = sanitize_search_query(query)
    assert "'" not in result
    assert ";" not in result
    assert result == "test DROP TABLE transcriptions --"
```

**XSS (Cross-Site Scripting)**:
```python
def test_xss_script_tag():
    """Test blocking XSS script tag injection."""
    query = "<script>alert('XSS')</script>"
    result = sanitize_search_query(query)
    assert "<" not in result
    assert ">" not in result
    assert result == "scriptalertXSS/script"
```

**Command Injection**:
```python
def test_command_injection():
    """Test blocking command injection semicolons."""
    query = "test; rm -rf /"
    result = sanitize_search_query(query)
    assert ";" not in result
    assert result == "test rm -rf /"
```

**Path Traversal** (file service tests):
```python
def test_path_traversal_unix():
    """Test sanitization of Unix path traversal."""
    filename = "../../etc/passwd"
    result = file_service.sanitize_filename(filename)
    assert result == "etcpasswd.mp3"
    assert ".." not in result
```

**Test Categories**:
1. SQL injection (DROP, UNION, OR bypass)
2. XSS (script tags, img onerror, iframe)
3. JavaScript handlers (onload, onclick)
4. Path traversal (Unix, Windows)
5. Command injection (semicolons, pipes)
6. Null byte injection
7. Special characters
8. Unicode/emoji handling
9. Length limits
10. Edge cases (empty, whitespace)

### 9.3 Integration Testing

**Full Workflow Test**:
```python
def test_transcribe_audio_success(client):
    """Test full transcription workflow."""
    # 1. Upload MP3 file
    files = {"file": ("test.mp3", mp3_bytes, "audio/mpeg")}
    response = client.post("/api/v1/transcribe", files=files)

    # 2. Verify response
    assert response.status_code == 201
    data = response.json()
    assert "id" in data
    assert "transcribed_text" in data

    # 3. Verify database persistence
    transcriptions = client.get("/api/v1/transcriptions").json()
    assert len(transcriptions) == 1
    assert transcriptions[0]["id"] == data["id"]
```

### 9.4 Dependency Injection for Testing

**Production**:
```python
def get_whisper_service() -> WhisperModelService:
    return WhisperModelService()  # Real model
```

**Testing**:
```python
class FakeWhisperService:
    def transcribe(self, audio_path: Path) -> str:
        return "Fake transcription"  # No model loading

def get_fake_whisper_service() -> FakeWhisperService:
    return FakeWhisperService()

# Override dependency
app.dependency_overrides[get_whisper_service] = get_fake_whisper_service

# Tests now use fake service (fast, no model loading)
```

**Benefits**:
- Tests run in seconds, not minutes
- No GPU required for CI/CD
- Isolate logic from ML model

---

## 11. Frontend Architecture

### 10.1 Current State

**Technology**: React 18 + TypeScript + Vite

**Features**:
- Audio file upload (drag-and-drop + file picker)
- Real-time transcription display
- Transcription history list
- Search by filename
- Error handling with user-friendly messages

**Structure**:
```
frontend/src/
├── App.tsx               # Main component
├── components/
│   ├── FileUpload.tsx    # Upload interface
│   ├── TranscriptionList.tsx  # History display
│   └── SearchBar.tsx     # Filename search
└── api/
    └── client.ts         # API client (fetch wrappers)
```

### 10.2 API Integration

**Example API Client**:
```typescript
// frontend/src/api/client.ts
const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:8000"

export async function transcribeAudio(file: File): Promise<Transcription> {
  const formData = new FormData()
  formData.append("file", file)

  const response = await fetch(`${API_BASE}/api/v1/transcribe`, {
    method: "POST",
    body: formData,
  })

  if (!response.ok) {
    throw new Error(`Transcription failed: ${response.statusText}`)
  }

  return response.json()
}
```

### 10.3 Production Enhancements Needed

See **Section 12.5** (Production vs Assessment - Frontend Changes) for comprehensive list:

- Production build with minification
- React Router for multi-page navigation
- State management (Redux/Zustand) for complex state
- Environment-based API endpoints
- Error boundaries with fallback UI
- Analytics tracking
- Performance optimization (code splitting, lazy loading)

---

## 12. Design Trade-offs & Decisions

### 11.1 SQLite vs PostgreSQL

**Assessment Choice**: SQLite

**Reasons**:
- ✅ Zero setup (single file, no server)
- ✅ Fast for single-instance app
- ✅ Easy for reviewers to run locally
- ✅ Sufficient for demonstration

**Trade-offs**:
- ❌ No concurrent writes (write lock blocks other transactions)
- ❌ No replication/high availability
- ❌ Limited to single instance
- ❌ No advanced features (full-text search, JSON operators, CTEs)

**Production**: PostgreSQL
- ✅ Concurrent writes
- ✅ Read replicas for scaling
- ✅ Advanced indexing (GIN, GiST for full-text search)
- ✅ ACID compliance at scale
- ✅ Managed services (RDS, CloudSQL)

### 11.2 Synchronous Transcription vs Background Jobs

**Assessment Choice**: Synchronous (wait for transcription to complete)

**Reasons**:
- ✅ Simpler implementation (no queue infrastructure)
- ✅ Immediate feedback (no polling for status)
- ✅ Easier for reviewers to test

**Trade-offs**:
- ❌ Long request times (10-30s for 5-minute audio)
- ❌ Ties up web workers (can't handle other requests)
- ❌ Risk of timeout (default 30s HTTP timeout)
- ❌ Poor user experience for long files

**Production**: Background Jobs (Celery + Redis)
- ✅ Immediate response (return job ID, poll for status)
- ✅ Web workers free to handle other requests
- ✅ Scale workers independently (add more for peak load)
- ✅ Retry failed transcriptions automatically
- ✅ Progress updates via WebSockets
- ✅ Job queues with priority (premium users first)

**Implementation**:
```python
# Production: Background job
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile):
    # Save file
    filename, file_path = await file_service.save_file(file)

    # Enqueue job
    job = transcribe_task.delay(str(file_path))

    # Return job ID immediately
    return {"job_id": job.id, "status": "pending"}

# Poll endpoint
@app.get("/api/v1/jobs/{job_id}")
async def get_job_status(job_id: str):
    job = AsyncResult(job_id)
    return {"status": job.status, "result": job.result}
```

### 11.3 No Authentication (Assessment Only)

**Assessment Choice**: No authentication/authorization

**Reasons**:
- ✅ Focus on core transcription functionality
- ✅ Simpler testing for reviewers
- ✅ Avoid complexity of user management

**Trade-offs**:
- ❌ Anyone can upload/search (no privacy)
- ❌ No per-user rate limiting
- ❌ Can't track usage by user
- ❌ Can't implement user-specific features

**Production**: JWT Authentication
- ✅ Per-user rate limits
- ✅ Private transcriptions (users see only their own)
- ✅ Usage tracking and billing
- ✅ Role-based access (admin, user, guest)

**Implementation**:
```python
# JWT middleware
@app.post("/api/v1/transcribe")
async def transcribe_audio(
    file: UploadFile,
    user: User = Depends(get_current_user),  # JWT validation
):
    # Check user quota
    if user.transcription_count >= user.plan.max_transcriptions:
        raise HTTPException(status_code=402, detail="Quota exceeded")

    # Associate transcription with user
    transcription = repository.create(
        audio_filename=filename,
        transcribed_text=text,
        user_id=user.id,  # Track ownership
    )
```

### 11.4 Local File Storage vs Object Storage

**Assessment Choice**: Local filesystem

**Reasons**:
- ✅ Simplest implementation
- ✅ No external dependencies
- ✅ Fast for single instance

**Trade-offs**:
- ❌ Limited to single instance (can't share files across servers)
- ❌ No redundancy (disk failure = data loss)
- ❌ Scales with instance disk size (expensive)
- ❌ No CDN acceleration

**Production**: S3 / Object Storage
- ✅ Unlimited scalable storage
- ✅ Multi-region redundancy
- ✅ CDN integration for fast downloads
- ✅ Lifecycle policies (archive old files to Glacier)
- ✅ Presigned URLs for secure direct uploads

**Implementation**:
```python
# Production: S3 upload
import boto3

s3 = boto3.client("s3")

async def save_file(self, file: UploadFile) -> tuple[str, str]:
    """Save file to S3 and return S3 key."""
    unique_filename = self.generate_unique_filename(file.filename)

    # Stream upload to S3
    s3.upload_fileobj(
        file.file,
        bucket="audio-transcriptions",
        key=f"uploads/{unique_filename}",
    )

    return unique_filename, f"s3://audio-transcriptions/uploads/{unique_filename}"
```

### 11.5 CPU/MPS vs GPU

**Assessment Choice**: CPU/MPS (Apple Silicon)

**Reasons**:
- ✅ Works on laptop (no GPU required)
- ✅ Fast enough for small files (<5 minutes)
- ✅ Easy local testing

**Trade-offs**:
- ❌ Slow for long audio (30s+ for 5-minute file on CPU)
- ❌ Can't scale to high throughput
- ❌ Blocks during transcription (synchronous)

**Production**: GPU Instances (CUDA)
- ✅ 10-100x faster than CPU
- ✅ Handle longer audio files efficiently
- ✅ Batch processing (multiple files at once)
- ✅ Lower cost per transcription at scale

**Infrastructure**:
- AWS: g5.xlarge (NVIDIA A10G GPU)
- GCP: n1-standard-4 + NVIDIA T4
- Azure: NC6s v3 (NVIDIA V100)

**Cost Comparison** (1000 hours of audio):
- CPU: 1000 hours * 30s = 8.3 hours compute time
- GPU: 1000 hours * 1s = 0.3 hours compute time
- **GPU is cheaper** at high volume despite higher per-hour cost

---

## 13. Production vs Assessment Comparison

### 12.1 Architecture Changes

| Component | Assessment | Production | Why Change? |
|-----------|------------|------------|-------------|
| **Database** | SQLite single file | PostgreSQL with read replicas | Concurrent writes, scalability |
| **Transcription** | Synchronous (blocking) | Celery background jobs with Redis | Non-blocking, scalable workers |
| **File Storage** | Local filesystem | S3 / object storage | Multi-instance, redundancy, CDN |
| **App Server** | Uvicorn single process | Gunicorn with multiple workers | Handle concurrent requests |
| **Instances** | Single instance | Multi-instance + load balancer | High availability, auto-scaling |
| **Caching** | No caching layer | Redis for frequent queries | Reduce DB load |
| **ML Hardware** | CPU/MPS | GPU instances (CUDA) | 10-100x faster inference |

### 12.2 Security Enhancements

| Security Layer | Assessment | Production | Why Change? |
|----------------|------------|------------|-------------|
| **Authentication** | None (open API) | JWT tokens with refresh | Per-user access control |
| **Rate Limiting** | IP-based (in-memory) | Redis-backed per-user quotas | Fair use, prevent abuse |
| **CORS** | `localhost:5173` | Production domain whitelist | Prevent unauthorized access |
| **HTTPS** | HTTP only | HTTPS with TLS 1.3 | Encrypt data in transit |
| **Secrets** | `.env` file | Secrets manager (Vault, AWS Secrets) | Rotate credentials, audit access |
| **Security Headers** | Basic | CSP, HSTS, X-Frame-Options | XSS/clickjacking protection |
| **Monitoring** | Basic logs | APM + SIEM (DataDog, Sentry) | Detect attacks, audit logs |
| **Input Validation** | Sanitization only | WAF (Web Application Firewall) | Block malicious traffic before it hits app |

**Additional Production Security**:
```python
# Security headers middleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.sessions import SessionMiddleware

app.add_middleware(TrustedHostMiddleware, allowed_hosts=["app.example.com"])

@app.middleware("http")
async def add_security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = "default-src 'self'"
    return response
```

### 12.3 Database Changes

| Feature | SQLite (Assessment) | PostgreSQL (Production) | Impact |
|---------|---------------------|-------------------------|--------|
| **Connection Pooling** | Not needed | PgBouncer + SQLAlchemy pool | Handle 1000+ concurrent connections |
| **Indexes** | Basic primary key | Composite, GIN full-text, partial | 100x faster queries |
| **Backups** | Manual file copy | Automated daily + point-in-time recovery | Data safety, disaster recovery |
| **Replication** | None | Primary + 2 read replicas | Scale reads, high availability |
| **Transactions** | Single writer lock | MVCC (Multi-Version Concurrency Control) | True concurrent writes |
| **Query Optimization** | Basic | EXPLAIN ANALYZE, query planner tuning | Optimize slow queries |

**Full-Text Search** (PostgreSQL):
```python
# Add GIN index for full-text search
transcribed_text_tsv: Mapped[TSVector] = mapped_column(
    TSVector,
    Computed("to_tsvector('english', transcribed_text)", persisted=True)
)

# Create GIN index
Index("idx_transcribed_text_tsv", Transcription.transcribed_text_tsv, postgresql_using="gin")

# Search query
stmt = select(Transcription).where(
    Transcription.transcribed_text_tsv.match("climate change")
)
```

**Connection Pooling**:
```python
# SQLAlchemy connection pool
engine = create_engine(
    "postgresql://user:pass@host/db",
    pool_size=20,           # Keep 20 connections open
    max_overflow=10,        # Allow 10 additional connections under load
    pool_pre_ping=True,     # Test connections before use
    pool_recycle=3600,      # Recycle connections every hour
)
```

### 12.4 ML Model Scaling

| Aspect | Assessment | Production | Improvement |
|--------|------------|------------|-------------|
| **Hardware** | CPU/MPS | GPU (A100, V100) | 10-100x faster |
| **Model Size** | Whisper Tiny | Whisper Base/Medium | Better accuracy |
| **Processing** | Synchronous blocking | Async queue with workers | Throughput 100x+ |
| **Caching** | No caching | Redis cache for repeated audio (hash-based) | Avoid duplicate work |
| **Model Versioning** | Single model | A/B testing, gradual rollout | Test improvements safely |
| **Batch Processing** | One file at a time | Batched inference (10+ files) | GPU utilization 10x better |

**Background Job Queue** (Celery + Redis):
```python
# celery_app.py
from celery import Celery

app = Celery("transcription", broker="redis://localhost:6379/0")

@app.task(bind=True, max_retries=3)
def transcribe_task(self, audio_path: str) -> dict:
    """Background transcription task."""
    try:
        whisper = get_whisper_service()
        text = whisper.transcribe(audio_path)

        # Save to database
        repository = TranscriptionRepository(db)
        transcription = repository.create(
            audio_filename=Path(audio_path).name,
            transcribed_text=text,
        )

        return {"id": transcription.id, "text": text}

    except Exception as e:
        # Retry with exponential backoff
        self.retry(exc=e, countdown=2 ** self.request.retries)
```

**API Changes**:
```python
# Immediate response with job ID
@app.post("/api/v1/transcribe")
async def transcribe_audio(file: UploadFile):
    filename, file_path = await file_service.save_file(file)

    # Enqueue background job
    job = transcribe_task.delay(str(file_path))

    return {
        "job_id": job.id,
        "status": "pending",
        "poll_url": f"/api/v1/jobs/{job.id}"
    }

# Poll for status
@app.get("/api/v1/jobs/{job_id}")
async def get_job_status(job_id: str):
    job = AsyncResult(job_id)

    if job.ready():
        return {"status": "completed", "result": job.result}
    else:
        return {"status": "pending", "progress": job.info.get("progress", 0)}
```

**GPU Batch Processing**:
```python
# Process multiple files in one GPU batch for efficiency
def transcribe_batch(audio_paths: list[Path]) -> list[str]:
    """Transcribe multiple files in one batch (GPU efficiency)."""
    whisper = get_whisper_service()

    # Load all audio files
    audios = [load_audio(path) for path in audio_paths]

    # Batch inference (utilize GPU better)
    results = whisper._pipeline(audios, batch_size=8)

    return [r["text"] for r in results]
```

### 12.5 API/Infrastructure Changes

| Component | Assessment | Production | Why |
|-----------|------------|------------|-----|
| **Web Server** | Uvicorn single process | Gunicorn + Uvicorn workers | Handle concurrent requests |
| **Load Balancer** | None | AWS ALB / NGINX | Distribute traffic, SSL termination |
| **API Versioning** | `/api/v1/` (no strategy) | Versioning + deprecation policy | Backward compatibility |
| **Error Handling** | Basic HTTPException | Circuit breakers, retry logic | Graceful degradation |
| **Webhooks** | None | Notify on completion | Async user notification |
| **Pagination** | Return all results | Cursor-based pagination | Efficient large datasets |
| **Health Checks** | Simple `/health` | Liveness + Readiness probes | Kubernetes auto-recovery |

**Gunicorn + Uvicorn Workers**:
```bash
# Production: Multiple worker processes
gunicorn main:app \
  --workers 4 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --timeout 120 \
  --graceful-timeout 30 \
  --keep-alive 5
```

**API Versioning**:
```python
# /api/v2/ for breaking changes
@app.post("/api/v2/transcribe")
async def transcribe_audio_v2(file: UploadFile):
    # New API with job queue
    job = transcribe_task.delay(str(file_path))
    return {"job_id": job.id}

# Keep v1 for backward compatibility (deprecated)
@app.post("/api/v1/transcribe")
@deprecated(message="Use /api/v2/transcribe instead")
async def transcribe_audio_v1(file: UploadFile):
    # Old synchronous API
    ...
```

**Cursor-Based Pagination**:
```python
@app.get("/api/v1/transcriptions")
async def list_transcriptions(
    cursor: str | None = None,
    limit: int = 50,
    db: Session = Depends(get_db),
):
    """List transcriptions with cursor-based pagination."""
    repository = TranscriptionRepository(db)

    if cursor:
        # Decode cursor (base64-encoded timestamp)
        cursor_ts = decode_cursor(cursor)
        stmt = select(Transcription).where(
            Transcription.created_timestamp < cursor_ts
        ).order_by(Transcription.created_timestamp.desc()).limit(limit)
    else:
        stmt = select(Transcription).order_by(
            Transcription.created_timestamp.desc()
        ).limit(limit)

    results = db.execute(stmt).scalars().all()

    # Generate next cursor
    next_cursor = None
    if len(results) == limit:
        next_cursor = encode_cursor(results[-1].created_timestamp)

    return {
        "results": results,
        "next_cursor": next_cursor,
        "has_more": next_cursor is not None,
    }
```

### 12.6 Frontend Production Changes

| Feature | Assessment | Production | Why |
|---------|------------|------------|-----|
| **Build** | Dev build | Production build (minified, tree-shaken) | 10x smaller bundle size |
| **Routing** | Single page | React Router for multi-page navigation | Better UX, SEO |
| **State Management** | Local state only | Redux/Zustand for complex state | Predictable state updates |
| **API Endpoints** | Hard-coded localhost | Environment-based config | Dev/staging/prod environments |
| **Error Boundaries** | None | React error boundaries with fallback UI | Graceful error handling |
| **Analytics** | None | Google Analytics, Mixpanel | Track user behavior |
| **Performance** | No optimization | Code splitting, lazy loading | Faster initial load |
| **CDN** | Local assets | CloudFront for static assets | Fast global delivery |

**Production Build**:
```bash
# Development: ~5MB unminified
npm run dev

# Production: ~200KB minified + gzipped
npm run build
```

**Environment-Based Config**:
```typescript
// frontend/.env.production
VITE_API_URL=https://api.example.com

// frontend/.env.development
VITE_API_URL=http://localhost:8000

// frontend/src/api/client.ts
const API_BASE = import.meta.env.VITE_API_URL
```

**Error Boundary**:
```typescript
class ErrorBoundary extends React.Component {
  state = { hasError: false }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  render() {
    if (this.state.hasError) {
      return <div>Something went wrong. Please refresh.</div>
    }
    return this.props.children
  }
}
```

### 12.7 DevOps/Deployment Changes

| Aspect | Assessment | Production | Why |
|--------|------------|------------|-----|
| **Local Dev** | Manual `uvicorn main:app` | Docker Compose for consistent environment | Same env as production |
| **CI/CD** | None | GitHub Actions for automated testing + deployment | Catch bugs before production |
| **Deployment** | Manual | Blue-green or canary deployments | Zero-downtime updates |
| **Orchestration** | Single instance | Kubernetes with auto-scaling | Handle traffic spikes |
| **Health Checks** | None | Liveness/readiness probes | Auto-restart failed pods |
| **Monitoring** | Print statements | Prometheus + Grafana dashboards | Real-time metrics |
| **Logging** | Stdout | Centralized logging (ELK, CloudWatch) | Aggregate logs from all instances |
| **Alerting** | None | PagerDuty/Opsgenie for critical issues | 24/7 incident response |

**Docker Compose** (local dev):
```yaml
# docker-compose.yml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/transcriptions
      - REDIS_URL=redis://redis:6379/0
    depends_on:
      - db
      - redis

  db:
    image: postgres:16
    environment:
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass
      - POSTGRES_DB=transcriptions
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

  celery_worker:
    build: ./backend
    command: celery -A celery_app worker --loglevel=info
    depends_on:
      - redis
      - db

volumes:
  postgres_data:
```

**Kubernetes Deployment**:
```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: transcription-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: transcription-api
  template:
    metadata:
      labels:
        app: transcription-api
    spec:
      containers:
      - name: api
        image: transcription-api:v1.2.3
        ports:
        - containerPort: 8000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: url
        livenessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: transcription-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: transcription-api
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

**Monitoring Stack** (Prometheus + Grafana):
```python
# Add metrics endpoint
from prometheus_client import Counter, Histogram, make_asgi_app

transcription_requests = Counter(
    "transcription_requests_total",
    "Total transcription requests",
    ["status"]
)

transcription_duration = Histogram(
    "transcription_duration_seconds",
    "Transcription duration in seconds"
)

@app.post("/api/v1/transcribe")
@transcription_duration.time()
async def transcribe_audio(file: UploadFile):
    try:
        # ... transcription logic ...
        transcription_requests.labels(status="success").inc()
        return result
    except Exception as e:
        transcription_requests.labels(status="error").inc()
        raise

# Expose metrics endpoint
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)
```

### 12.8 Cost Optimization

| Resource | Assessment (Free) | Production (Optimized) | Savings |
|----------|-------------------|------------------------|---------|
| **GPU Usage** | Always-on | Spot instances + auto-shutdown | 70% |
| **Storage** | All files kept | Lifecycle policies (archive after 90 days) | 80% |
| **Database** | SQLite (free) | RDS with reserved instances | 60% vs on-demand |
| **CDN** | No CDN | CloudFront for static assets | Reduce origin load |
| **Multi-Region** | Single region | Primary region + CDN edge caching | Latency reduction |

**Spot Instances** (AWS):
```python
# Use spot instances for batch transcription workers
# 70% cheaper than on-demand, with interruption handling

@app.task(bind=True)
def transcribe_task(self, audio_path: str):
    try:
        # ... transcription logic ...
    except SpotInstanceInterruption:
        # Re-queue task if spot instance interrupted
        self.retry(countdown=60)
```

**S3 Lifecycle Policy**:
```json
{
  "Rules": [
    {
      "Id": "Archive old audio",
      "Status": "Enabled",
      "Transitions": [
        {
          "Days": 90,
          "StorageClass": "GLACIER"
        }
      ],
      "Expiration": {
        "Days": 365
      }
    }
  ]
}
```

### 12.9 Compliance & Legal

| Requirement | Assessment | Production | Why |
|-------------|------------|------------|-----|
| **Data Retention** | No policy | GDPR-compliant deletion | Legal requirement (EU) |
| **Terms of Service** | None | Legal review for audio data processing | Liability protection |
| **Privacy Policy** | None | Disclosure of data usage | GDPR/CCPA compliance |
| **Encryption** | HTTP only | HTTPS + encryption at rest | Data protection |
| **Audit Logs** | None | Immutable audit trail | Compliance reporting |

**GDPR Right to Deletion**:
```python
@app.delete("/api/v1/users/{user_id}/data")
async def delete_user_data(
    user_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Delete all user data (GDPR right to erasure)."""
    if user.id != user_id and not user.is_admin:
        raise HTTPException(status_code=403)

    # Delete transcriptions
    db.query(Transcription).filter(Transcription.user_id == user_id).delete()

    # Delete audio files from S3
    s3_keys = db.query(Transcription.s3_key).filter(
        Transcription.user_id == user_id
    ).all()
    for key in s3_keys:
        s3.delete_object(Bucket="audio-transcriptions", Key=key)

    # Log deletion for audit trail
    audit_log.info(f"User {user_id} data deleted (GDPR request)")

    db.commit()
    return {"message": "All data deleted"}
```

### 12.10 When to Implement Each Change

**Priority Matrix**:

| Priority | Changes | Timing |
|----------|---------|--------|
| **P0 (Launch Blockers)** | HTTPS, PostgreSQL, Authentication | Before first user |
| **P1 (First 100 Users)** | Background jobs, Redis caching, monitoring | Within 1 month |
| **P2 (First 1000 Users)** | GPU instances, S3 storage, load balancing | Within 3 months |
| **P3 (Scale to 10K+ Users)** | Multi-region, read replicas, Kubernetes | Within 6 months |
| **P4 (Enterprise Features)** | Compliance features, audit logs, SLAs | As needed |

---

## 14. Deployment Considerations

### 13.1 Docker Containerization

**Dockerfile** (multi-stage build):
```dockerfile
# Stage 1: Build dependencies
FROM python:3.12-slim AS builder

WORKDIR /app

# Install uv (fast Python package manager)
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv

# Copy dependency files
COPY pyproject.toml uv.lock ./

# Install dependencies
RUN uv sync --frozen --no-dev

# Stage 2: Runtime
FROM python:3.12-slim

WORKDIR /app

# Copy dependencies from builder
COPY --from=builder /app/.venv /app/.venv

# Copy application code
COPY src/ ./src/

# Create data directories
RUN mkdir -p data/uploads .cache/whisper

# Expose port
EXPOSE 8000

# Run application
CMD [".venv/bin/uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

**Benefits of Multi-Stage Build**:
- Smaller image size (only runtime dependencies)
- Faster builds (cache layers)
- Separate build and runtime concerns

### 13.2 Environment Configuration

**Production `.env`**:
```bash
# App
DEBUG=false
APP_NAME="Audio Transcription API"

# Database
DATABASE_URL=postgresql://user:password@db.example.com:5432/transcriptions

# Redis
REDIS_URL=redis://redis.example.com:6379/0

# AWS
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_S3_BUCKET=audio-transcriptions
AWS_REGION=us-east-1

# Model
WHISPER_MODEL_NAME=openai/whisper-base
MODEL_CACHE_DIR=/app/.cache/whisper

# API
CORS_ORIGINS=https://app.example.com,https://www.example.com
TRANSCRIBE_RATE_LIMIT=10/minute

# Monitoring
SENTRY_DSN=https://...@sentry.io/...
```

**Secrets Management** (Production):
- ❌ Don't commit `.env` to Git
- ✅ Use AWS Secrets Manager, HashiCorp Vault, or Kubernetes Secrets
- ✅ Rotate secrets regularly
- ✅ Audit access to secrets

### 13.3 Production Checklist

**Before Launch**:
- [ ] Switch to PostgreSQL
- [ ] Enable HTTPS (TLS certificate)
- [ ] Set up authentication (JWT)
- [ ] Configure CORS for production domain
- [ ] Set DEBUG=false
- [ ] Configure logging (centralized)
- [ ] Set up monitoring (APM, metrics)
- [ ] Set up error tracking (Sentry)
- [ ] Configure backups (database, files)
- [ ] Set up CI/CD pipeline
- [ ] Load testing (ensure performance)
- [ ] Security audit (penetration testing)
- [ ] Create runbook for incidents
- [ ] Set up on-call rotation

**Health Check Endpoint** (Kubernetes):
```python
@app.get("/api/v1/health")
async def health_check(
    whisper: WhisperModelService = Depends(get_whisper_service),
    db: Session = Depends(get_db),
):
    """Health check for liveness/readiness probes."""
    checks = {
        "model_loaded": whisper.is_loaded,
        "database": False,
    }

    # Test database connection
    try:
        db.execute(text("SELECT 1"))
        checks["database"] = True
    except Exception:
        checks["database"] = False

    # Fail if any check fails
    if not all(checks.values()):
        raise HTTPException(status_code=503, detail=checks)

    return {
        "status": "healthy",
        "checks": checks,
        "timestamp": datetime.now(timezone.utc),
    }
```

### 13.4 Infrastructure as Code (Terraform)

**Example: AWS Infrastructure**:
```hcl
# terraform/main.tf
resource "aws_ecs_cluster" "transcription" {
  name = "transcription-cluster"
}

resource "aws_ecs_task_definition" "api" {
  family = "transcription-api"

  container_definitions = jsonencode([{
    name  = "api"
    image = "transcription-api:latest"

    environment = [
      { name = "DATABASE_URL", value = aws_db_instance.postgres.endpoint },
      { name = "REDIS_URL", value = aws_elasticache_cluster.redis.cache_nodes[0].address },
    ]

    portMappings = [{
      containerPort = 8000
      hostPort      = 8000
    }]
  }])

  requires_compatibilities = ["FARGATE"]
  cpu                      = "512"
  memory                   = "2048"
}

resource "aws_db_instance" "postgres" {
  identifier     = "transcription-db"
  engine         = "postgres"
  engine_version = "16"
  instance_class = "db.t3.medium"

  allocated_storage = 100
  storage_encrypted = true

  backup_retention_period = 7

  multi_az = true  # High availability
}

resource "aws_elasticache_cluster" "redis" {
  cluster_id      = "transcription-redis"
  engine          = "redis"
  node_type       = "cache.t3.micro"
  num_cache_nodes = 1
}
```

---

## 15. Technical Deep Dives

### 14.1 `__new__` vs `__init__` (Singleton Implementation)

<details>
<summary><strong>Deep Dive: Object Creation in Python</strong></summary>

**Object Creation Flow**:
1. Python calls `__new__()` → Creates empty object in memory
2. Python calls `__init__()` → Initializes object attributes
3. Python returns initialized object

**`__new__`**: Allocator (creates the object)
- Static method (receives class, not instance)
- Returns a new instance
- Responsible for memory allocation
- Runs **before** `__init__`

**`__init__`**: Initializer (sets up the object)
- Instance method (receives self)
- Doesn't return anything
- Populates object attributes
- Runs **after** `__new__`

**Why You Never Call `__new__` from `__init__`**:
By the time `__init__` runs, the object already exists (created by `__new__`). Calling `__new__` again would create a duplicate object, breaking the singleton pattern.

**Singleton Override**:
```python
def __new__(cls):
    """Override allocator to return same instance."""
    if cls._instance is None:
        cls._instance = super().__new__(cls)  # Call parent allocator once
    return cls._instance  # Always return same instance

def __init__(self):
    """Initialize only once (idempotent)."""
    if self._initialized:
        return  # Skip if already initialized

    # First-time initialization
    self._model = load_model()
    self._initialized = True
```
</details>

### 14.2 MRO (Method Resolution Order)

<details>
<summary><strong>Deep Dive: Method Resolution Order</strong></summary>

**MRO**: The ordered list of classes Python searches when looking up attributes/methods.

**Algorithm**: C3 Linearization (respects inheritance order, avoids duplicates)

**WhisperModelService MRO**:
```python
WhisperModelService.__mro__
# (<class 'WhisperModelService'>, <class 'object'>)
```

**Why `super().__new__(cls)` works**:
- `super()` finds the next class in MRO (object)
- `object.__new__(cls)` creates a new instance
- Returns empty WhisperModelService instance

**Multiple Inheritance Example**:
```python
class A:
    def method(self): print("A")

class B(A):
    def method(self): print("B")

class C(A):
    def method(self): print("C")

class D(B, C):
    pass

D.__mro__
# (<class 'D'>, <class 'B'>, <class 'C'>, <class 'A'>, <class 'object'>)

D().method()  # Prints "B" (first in MRO after D)
```

**Why MRO Matters**:
- Determines which method gets called in inheritance hierarchies
- Prevents diamond problem (same method in multiple parents)
- `super()` follows MRO automatically (no hard-coded parent class)
</details>

### 14.3 Double-Checked Locking

<details>
<summary><strong>Deep Dive: Thread Safety in Singletons</strong></summary>

**Problem**: Race condition without locking

```python
# UNSAFE: Race condition
def __new__(cls):
    if cls._instance is None:           # Thread A and B both see None
        cls._instance = super().__new__(cls)  # Both create instances!
    return cls._instance
```

**Timeline**:
1. Thread A: Checks `_instance is None` → True
2. **Context switch** (Thread A paused)
3. Thread B: Checks `_instance is None` → True (A hasn't assigned yet)
4. Thread B: Creates instance, assigns to `_instance`
5. **Context switch** (Thread B paused)
6. Thread A: Creates **second** instance, **overwrites** `_instance`
7. Result: Two instances created, breaks singleton

**Solution 1: Always Lock (slow)**:
```python
def __new__(cls):
    with cls._lock:  # Acquire lock EVERY time
        if cls._instance is None:
            cls._instance = super().__new__(cls)
    return cls._instance
```

**Downside**: Lock acquired on every call, even after instance created (99.99% of calls).

**Solution 2: Double-Checked Locking (fast)**:
```python
def __new__(cls):
    if cls._instance is None:       # First check (no lock, fast path)
        with cls._lock:             # Acquire lock only if None
            if cls._instance is None:  # Second check (thread-safe)
                cls._instance = super().__new__(cls)
    return cls._instance
```

**How It Works**:
1. **First check** (outside lock): Fast path for already-initialized case (99.99% of calls)
2. **Lock**: Only acquired if first check sees None
3. **Second check** (inside lock): Ensures only one thread creates instance

**Timeline (Safe)**:
1. Thread A: First check → None, acquire lock
2. Thread B: First check → None, **blocked on lock**
3. Thread A: Second check → None, creates instance, releases lock
4. Thread B: Acquires lock, second check → **Not None**, returns existing instance

**Performance**:
- First call: ~0.1ms (lock acquisition + instance creation)
- Subsequent calls: ~0.001ms (no lock, just return)
- 100x faster than always locking
</details>

### 14.4 SQLAlchemy Session Identity Map

<details>
<summary><strong>Deep Dive: How Sessions Track Objects</strong></summary>

**Identity Map**: In-memory cache of objects keyed by (table, primary_key).

**Example**:
```python
# First query
user1 = db.query(User).filter(User.id == 1).first()

# Second query (same ID)
user2 = db.query(User).filter(User.id == 1).first()

# Same Python object!
assert user1 is user2  # True
```

**How It Works**:
1. First query: Load row from database, create Python object, store in identity map
2. Second query: Check identity map first, return cached object (no database query)

**Benefits**:
- **Performance**: Avoid redundant queries
- **Consistency**: Same row → same Python object (not duplicates)
- **Change Tracking**: Modify object once, commit reflects changes

**Clearing Identity Map**:
```python
db.expunge(user)      # Remove specific object from identity map
db.expunge_all()      # Remove all objects
db.close()            # Clear identity map and close session
```

**Why Close Sessions**:
Identity map holds references to objects, preventing garbage collection. Always close sessions to free memory.
</details>

### 14.5 ReDoS (Regular Expression Denial of Service)

<details>
<summary><strong>Deep Dive: Regex Catastrophic Backtracking</strong></summary>

**Problem**: Some regex patterns have exponential time complexity due to backtracking.

**Vulnerable Pattern**:
```python
import re
pattern = r"(a+)+"  # Nested quantifiers
text = "a" * 50 + "!"  # 50 'a's + non-matching char

# Exponential backtracking - takes SECONDS
re.search(pattern, text)  # Tries all combinations of 'a' groups
```

**Why It's Slow**:
```
Pattern: (a+)+
Text: "aaaaaa!"

Attempts:
1. (aaaaaa)        - Fails on '!'
2. (aaaaa)(a)      - Fails on '!'
3. (aaaa)(aa)      - Fails on '!'
4. (aaaa)(a)(a)    - Fails on '!'
... 2^n combinations
```

**Attack**:
```python
# Attacker sends malicious search query
query = "a" * 10000 + "!"

# Server hangs for minutes/hours processing regex
sanitize_search_query(query)  # SLOW with vulnerable regex
```

**Solution: Google RE2**:
```python
import re2 as re  # Drop-in replacement

# Linear time, no backtracking
pattern = r"(a+)+"
text = "a" * 10000 + "!"
re.search(pattern, text)  # Fast (milliseconds)
```

**RE2 Guarantees**:
- Linear time complexity: O(n * m) where n=text length, m=pattern length
- No backtracking (uses automata-based matching)
- Sacrifices some regex features (lookahead, backreferences) for safety

**Project Usage** (`src/utils/security.py:3`):
```python
import re2 as re  # Use RE2, not standard re

def sanitize_search_query(query: str) -> str:
    # Safe from ReDoS attacks
    sanitized = re.sub(r"[<>\"';(){}\\]", "", query)
    return sanitized
```
</details>

---

## 16. Presentation Defense Strategy

### 15.1 Anticipating Common Questions

#### "Why Singleton for Whisper?"

**Answer Structure**:
1. **Problem**: Model is 150MB, takes 10s to load
2. **Without Singleton**: Load on every request → 15GB+ memory for 100 users
3. **With Singleton**: Load once, share across requests → 150MB total
4. **Thread Safety**: Double-checked locking prevents race conditions
5. **Performance**: First request 10s, subsequent <1s

**Follow-up**: "What about multiple models?"
- Could extend to model registry (map model name → instance)
- Factory pattern for multiple models if needed
- Current design optimizes for single-model assessment

#### "How do you prevent SQL injection?"

**Answer Structure**:
1. **Primary Defense**: SQLAlchemy ORM uses parameterized queries by design
2. **How Parameterization Works**: User input sent separately from SQL command
3. **Defense-in-Depth**: `sanitize_search_query()` adds extra layer
4. **Why Both**: Layered security (one failure doesn't compromise system)
5. **Testing**: 100+ attack pattern tests verify protection

**Example**:
```python
# ORM (safe)
stmt = select(Transcription).where(
    Transcription.audio_filename.contains(user_input)  # Parameterized
)

# Generated SQL
# SELECT * FROM transcriptions WHERE audio_filename LIKE ?
# Parameters: ["%user_input%"]
```

#### "What happens if transcription fails?"

**Answer Structure**:
1. **Error Handling**: Try-except in TranscriptionService
2. **Cleanup**: Delete uploaded file if transcription fails (transaction-like)
3. **User Feedback**: Return 500 error with generic message
4. **Logging**: Log error details for debugging (not exposed to user)
5. **Production**: Retry with exponential backoff in background job

**Code Reference** (`src/services/transcription_service.py:49-52`):
```python
try:
    transcribed_text = self._whisper_service.transcribe(file_path)
    transcription = self._repository.create(filename, transcribed_text)
    return transcription
except Exception as e:
    self._file_service.delete_file(filename)  # Cleanup
    logger.error(f"Transcription failed: {e}")
    raise HTTPException(status_code=500, detail="Transcription failed")
```

#### "How would you scale this?"

**Answer Structure**:
1. **Database**: SQLite → PostgreSQL with read replicas
2. **Processing**: Synchronous → Celery background jobs
3. **Storage**: Local → S3 with CDN
4. **Compute**: CPU → GPU instances for faster inference
5. **Architecture**: Single instance → Load-balanced multi-instance
6. **Caching**: Add Redis for frequent queries

**Detailed Roadmap**:
- **0-100 users**: Current architecture (SQLite, synchronous)
- **100-1000 users**: PostgreSQL + Redis + background jobs
- **1000-10K users**: GPU instances + S3 + load balancer
- **10K+ users**: Kubernetes + multi-region + auto-scaling

See **Section 12** for comprehensive production comparison.

#### "Why no authentication?"

**Answer Structure**:
1. **Assessment Scope**: Focus on core transcription functionality
2. **Trade-off**: Simplicity for reviewers vs production security
3. **Production Plan**: JWT authentication with per-user quotas
4. **What Changes**: See Section 12.2 (Security Enhancements)

**Production Implementation**:
```python
# JWT middleware
from fastapi_jwt_auth import AuthJWT

@app.post("/api/v1/transcribe")
async def transcribe_audio(
    file: UploadFile,
    auth: AuthJWT = Depends(),
):
    auth.jwt_required()  # Verify JWT token
    user_id = auth.get_jwt_subject()

    # Check user quota
    if user.transcription_count >= user.plan.max_transcriptions:
        raise HTTPException(status_code=402, detail="Quota exceeded")

    # Process transcription...
```

#### "What's your testing strategy?"

**Answer Structure**:
1. **Security-First**: 100+ tests for injection attacks
2. **Unit Tests**: Individual functions (sanitization, file validation)
3. **Integration Tests**: End-to-end API workflows
4. **Test Coverage**: Focus on security-critical paths
5. **Dependency Injection**: Mock services for fast tests

**Example**:
```python
# Unit test (fast, isolated)
def test_sanitize_sql_injection():
    query = "test'; DROP TABLE users; --"
    result = sanitize_search_query(query)
    assert "'" not in result
    assert ";" not in result

# Integration test (full workflow)
def test_transcribe_audio_success(client):
    files = {"file": ("test.mp3", mp3_bytes, "audio/mpeg")}
    response = client.post("/api/v1/transcribe", files=files)
    assert response.status_code == 201
```

### 15.2 Demonstrating Technical Depth

**Show Don't Tell**:
- Reference specific line numbers (`src/main.py:45`)
- Explain code with concrete examples
- Discuss trade-offs, not just implementation

**Example**: Instead of "I used Singleton pattern", say:

> "I implemented Singleton for WhisperModelService because the model is 150MB and takes 10 seconds to load. Without it, 100 concurrent users would create 100 instances, exhausting memory. I used double-checked locking for thread safety—first check without lock for fast path, then acquire lock and check again to prevent race conditions where multiple threads create instances. You can see the implementation in `src/services/whisper_service.py:27-33`."

### 15.3 Handling "Why Not X?" Questions

**Template**:
1. Acknowledge the alternative
2. Explain your choice with reasoning
3. Discuss trade-offs
4. Mention when you'd use the alternative

**Example**: "Why not use MongoDB instead of PostgreSQL?"

> "MongoDB is great for flexible schemas and document storage. I chose PostgreSQL because our data is highly structured (transcriptions have fixed fields like filename, text, timestamp), and we benefit from ACID transactions and relational constraints. For transcription search, PostgreSQL's full-text search with GIN indexes is faster than MongoDB's text indexes. However, if we needed to store unstructured metadata or had frequently changing schemas, MongoDB would be a better fit. For this use case, PostgreSQL's consistency guarantees and mature ecosystem were more valuable."

### 15.4 Admitting Limitations

**Be Honest About Shortcuts**:
- SQLite is development-friendly but not production-ready
- Synchronous transcription doesn't scale
- No authentication is assessment-only

**Frame Positively**:
> "I chose SQLite for the assessment because it's zero-setup and easy for reviewers to run locally. I'm aware it doesn't support concurrent writes and isn't suitable for production. For a real deployment, I'd use PostgreSQL with read replicas and connection pooling, as discussed in Section 12."

**Shows**:
- Self-awareness
- Production experience
- Pragmatic decision-making

---

## 17. Quick Reference

### 16.1 Key Concepts Cheat Sheet

| Concept | Definition | File Reference |
|---------|------------|----------------|
| **Singleton** | One instance per application lifecycle | `src/services/whisper_service.py:27` |
| **Repository** | Encapsulates database access | `src/utils/db.py:78` |
| **Service Layer** | Orchestrates business logic | `src/services/transcription_service.py:15` |
| **DI (Dependency Injection)** | Inject dependencies, don't instantiate | `src/main.py:109-111` |
| **ORM** | Map Python objects to database tables | `src/utils/db.py:54` |
| **Parameterization** | SQL injection prevention via ORM | `src/utils/db.py:105` |
| **Magic Bytes** | File type detection via header inspection | `src/services/file_service.py:82` |
| **Walrus Operator** | Assignment expression (`:=`) | `src/services/file_service.py:178` |
| **Chunked Reading** | Read files in small chunks to save memory | `src/services/file_service.py:178` |
| **Rate Limiting** | Restrict requests per IP/user | `src/main.py:103` |
| **CORS** | Cross-Origin Resource Sharing | `src/main.py:63` |
| **Lifespan** | Startup/shutdown hooks | `src/main.py:36` |
| **Double-Checked Locking** | Thread-safe singleton initialization | `src/services/whisper_service.py:29-33` |
| **Identity Map** | Session cache of loaded objects | `src/utils/db.py:36` |
| **ReDoS** | Regex denial of service (use RE2) | `src/utils/security.py:3` |

### 16.2 Design Patterns Summary

| Pattern | Where Used | Why Used | Key Benefit |
|---------|------------|----------|-------------|
| **Singleton** | WhisperModelService | Expensive to load, immutable | Memory efficiency, fast requests |
| **Repository** | TranscriptionRepository | Database access | Testability, maintainability |
| **Service Layer** | TranscriptionService | Business logic orchestration | Thin controllers, reusable logic |
| **Dependency Injection** | All services | Decouple creation from usage | Testability, flexibility |
| **Factory** | `get_*_service()` functions | Centralized instantiation | Easy testing, config changes |

### 16.3 Security Layers

| Layer | Protection | Implementation |
|-------|------------|----------------|
| **1. Extension** | Block non-.mp3 files | `file_service.py:52` |
| **2. Size** | Prevent memory exhaustion | `file_service.py:63` |
| **3. MIME** | Detect file type forgery | `file_service.py:79` |
| **4. Filename Sanitization** | Path traversal, injection | `file_service.py:94` |
| **5. Query Sanitization** | SQL/XSS/command injection | `security.py:6` |
| **6. ORM Parameterization** | SQL injection (primary) | `db.py:105` |
| **7. Rate Limiting** | API abuse, DoS | `main.py:103` |

### 16.4 File References

**Core Services**:
- `src/main.py`: FastAPI app, routes, middleware, lifespan
- `src/services/whisper_service.py`: ML model singleton
- `src/services/file_service.py`: Multi-layer file validation
- `src/services/transcription_service.py`: Business logic orchestration

**Infrastructure**:
- `src/utils/db.py`: SQLAlchemy models, repository, session
- `src/utils/security.py`: Sanitization functions (RE2-based)
- `src/utils/settings.py`: Configuration singleton
- `src/utils/schemas.py`: Pydantic response models

**Tests**:
- `tests/unit/test_security.py`: 100+ injection attack tests
- `tests/integration/test_api.py`: End-to-end workflows

### 16.5 Production Changes Priority

**P0 (Before Launch)**:
- Switch to PostgreSQL
- Enable HTTPS
- Add authentication (JWT)
- Configure production CORS

**P1 (First 100 Users)**:
- Background jobs (Celery + Redis)
- Monitoring (APM, metrics)
- Centralized logging

**P2 (First 1000 Users)**:
- GPU instances for transcription
- S3 for file storage
- Load balancing

**P3 (Scale to 10K+ Users)**:
- Kubernetes orchestration
- Read replicas
- Multi-region deployment

---

## Conclusion

This study guide covers the architecture, design patterns, security measures, and production considerations for the Audio Transcription API. It demonstrates:

- ✅ **Design Patterns**: Singleton, Repository, Service Layer, Dependency Injection
- ✅ **Security-First Thinking**: Multi-layer validation, defense-in-depth
- ✅ **Technical Depth**: Thread safety, ORM internals, performance optimization
- ✅ **Production Awareness**: Scalability roadmap, trade-off analysis
- ✅ **Code Quality**: 100+ tests, type safety, clean architecture

**Key Takeaways**:
1. **Patterns solve problems**: Every pattern has a clear "why" (Singleton for memory, Repository for testability)
2. **Security is layered**: Multiple independent checks (extension + size + MIME + sanitization)
3. **Trade-offs are intentional**: Assessment simplicity vs production scalability (SQLite vs PostgreSQL)
4. **Production readiness matters**: Clear roadmap from prototype to scale (Section 12)

**For Defense**:
- Reference specific line numbers for credibility
- Explain trade-offs, not just implementation
- Show production awareness (Section 12)
- Admit limitations positively (Section 15.4)

Good luck with your presentation! 🚀
