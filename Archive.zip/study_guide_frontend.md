# Frontend Study Guide - Audio Transcription App

**Last Updated**: January 2026
**Purpose**: Q&A style study guide for technical presentation and defense of frontend implementation

---

## Table of Contents

1. [React Fundamentals](#1-react-fundamentals)
2. [TypeScript Basics](#2-typescript-basics)
3. [Component Architecture](#3-component-architecture)
4. [State Management](#4-state-management)
5. [API Integration](#5-api-integration)
6. [Vite Build Tool](#6-vite-build-tool)
7. [Nginx Web Server](#7-nginx-web-server)
8. [Docker Multi-Stage Builds](#8-docker-multi-stage-builds)
9. [Environment Variables](#9-environment-variables)
10. [Validation Strategy](#10-validation-strategy)
11. [Polling vs WebSockets](#11-polling-vs-websockets)
12. [Debouncing](#12-debouncing)
13. [UI/UX Design](#13-uiux-design)
14. [Testing Strategy](#14-testing-strategy)
15. [Security Considerations](#15-security-considerations)

---

## 1. React Fundamentals

### What is React?

**Answer**: React is a JavaScript library for building user interfaces, developed by Facebook. It's component-based, meaning you build encapsulated components that manage their own state, then compose them to make complex UIs.

**Key Concepts**:
- **Components**: Reusable pieces of UI (like functions that return HTML)
- **JSX**: JavaScript XML - lets you write HTML-like syntax in JavaScript
- **Props**: Data passed from parent to child components (read-only)
- **State**: Data that changes over time within a component
- **Virtual DOM**: React creates a virtual representation of the DOM and efficiently updates only what changed

### Why use React for this project?

**Answer**:
1. **Component reusability**: FileUpload, TranscriptionList, SearchBar can be independently developed and tested
2. **Reactive updates**: When transcription status changes, UI automatically updates
3. **Large ecosystem**: Many libraries and tools available
4. **TypeScript support**: Excellent type checking for safer code
5. **Simple for single-page apps**: Perfect for our use case

### What is the Virtual DOM?

**Answer**: The Virtual DOM is a lightweight copy of the actual DOM kept in memory. When state changes:
1. React creates a new Virtual DOM tree
2. Compares it with the previous Virtual DOM (diffing)
3. Calculates the minimal set of changes needed
4. Updates only those parts in the real DOM

This is much faster than manipulating the real DOM directly.

---

## 2. TypeScript Basics

### What is TypeScript?

**Answer**: TypeScript is a typed superset of JavaScript that compiles to plain JavaScript. It adds optional static typing to JavaScript.

**Benefits**:
- **Type safety**: Catch errors at compile time, not runtime
- **Better IDE support**: Autocomplete, refactoring tools
- **Self-documenting code**: Types serve as inline documentation
- **Easier refactoring**: TypeScript catches breaking changes

### Example from our code:

```typescript
// Without TypeScript (JavaScript)
function uploadFiles(files) {
  // What type is files? What does it return?
  return fetch('/api/upload', { body: files });
}

// With TypeScript
async uploadFiles(files: File[]): Promise<TaskResponse[]> {
  // Clear: takes array of Files, returns Promise of TaskResponse array
  const response = await fetch('/api/upload', { body: files });
  return response.json();
}
```

### What are interfaces?

**Answer**: Interfaces define the shape of objects. They're like contracts that ensure objects have specific properties.

```typescript
export interface Transcription {
  id: number;
  audio_filename: string;
  transcribed_text: string | null;  // Can be string or null
  created_timestamp: string;
  status: 'processing' | 'completed' | 'failed';  // Only these 3 values
}
```

**Benefits**:
- Autocomplete when using `transcription.`
- Compiler error if you try to access non-existent property
- Refactoring is safer - TypeScript finds all usages

---

## 3. Component Architecture

### What components did we build?

**Answer**: We built 3 main components, each with a single responsibility:

1. **FileUpload**: Handles file selection, validation, upload, and status tracking
2. **TranscriptionList**: Displays transcriptions in a scrollable table
3. **SearchBar**: Handles search input with debouncing

### Why separate components?

**Answer**:
- **Single Responsibility Principle**: Each component does one thing well
- **Reusability**: Can reuse SearchBar in other contexts
- **Testability**: Easier to test isolated components
- **Maintainability**: Changes to search don't affect file upload
- **Team collaboration**: Different developers can work on different components

### FileUpload Component - What does it do?

**Answer**:
1. **File selection**: Drag-drop or click to browse
2. **Client-side validation**: Check file type and size before upload
3. **Upload**: Send files to backend API
4. **Status tracking**: Poll backend for transcription progress
5. **Display status**: Show pending/processing/completed/failed states

**Key features**:
- Validates files using environment variable limits
- Polls task status every 5 seconds
- Timeout after 60 attempts (5 minutes)
- Visual feedback for each file being processed

### TranscriptionList Component - What makes it scrollable?

**Answer**: We use CSS with `max-height` and `overflow-y`:

```css
.transcription-list {
  max-height: 500px;      /* Fixed height */
  overflow-y: auto;       /* Show scrollbar when content exceeds height */
  border: 1px solid #ddd;
}
```

**Why scrolling?**
- Prevents page from becoming infinitely long with many transcriptions
- Better UX - user can see other UI elements
- Sticky table headers stay visible while scrolling

**Implementation detail**:
```css
.transcription-list thead {
  position: sticky;    /* Header stays at top while scrolling */
  top: 0;
  background: #f5f5f5;
  z-index: 1;
}
```

### SearchBar Component - How does debouncing work?

**Answer**: Debouncing delays the search until the user stops typing.

**Without debouncing**:
- User types "test" → 4 API calls (t, te, tes, test)
- Wastes bandwidth, server resources
- Poor UX with flickering results

**With debouncing (500ms)**:
- User types "test" → Wait 500ms after last keystroke → 1 API call

**Implementation**:
```typescript
useEffect(() => {
  const timer = setTimeout(() => {
    setDebouncedQuery(query);  // Update after 500ms
  }, 500);

  return () => clearTimeout(timer);  // Cancel timer if user keeps typing
}, [query]);
```

---

## 4. State Management

### What is state in React?

**Answer**: State is data that changes over time within a component. When state changes, React re-renders the component.

### What is useState?

**Answer**: `useState` is a React Hook that lets you add state to functional components.

```typescript
const [count, setCount] = useState(0);
// count: current value
// setCount: function to update value
// 0: initial value
```

**Example from our code**:
```typescript
const [transcriptions, setTranscriptions] = useState<Transcription[]>([]);
const [loading, setLoading] = useState(false);
```

### What is useEffect?

**Answer**: `useEffect` is a React Hook that lets you perform side effects in functional components.

**Side effects**:
- Data fetching
- Subscriptions
- Manual DOM manipulation
- Timers

**Example from our code**:
```typescript
// Fetch transcriptions when component mounts
useEffect(() => {
  fetchTranscriptions();
}, []);  // Empty dependency array = run once on mount
```

**Dependency array**:
- `[]`: Run once on mount
- `[query]`: Run when `query` changes
- No array: Run on every render (usually not wanted)

### What is useCallback?

**Answer**: `useCallback` memoizes a function so it doesn't get recreated on every render.

```typescript
const fetchTranscriptions = useCallback(async () => {
  setLoading(true);
  const data = await apiService.listTranscriptions();
  setTranscriptions(data);
  setLoading(false);
}, []);  // Function only created once
```

**Why use it?**
- Prevents infinite loops when function is in useEffect dependency array
- Optimization: Avoids recreating function on every render

---

## 5. API Integration

### How do we call the backend API?

**Answer**: We use the native `fetch` API wrapped in a service class.

**ApiService class** (`services/api.ts`):
```typescript
class ApiService {
  private baseURL: string;

  constructor() {
    this.baseURL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
  }

  async uploadFiles(files: File[]): Promise<TaskResponse[]> {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));

    const response = await fetch(`${this.baseURL}/api/v1/transcribe`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Upload failed');
    }

    const data = await response.json();
    return data.tasks;
  }

  // Other methods...
}

export const apiService = new ApiService();
```

### Why use a service class?

**Answer**:
1. **Centralized API logic**: All API calls in one place
2. **Reusability**: Multiple components can use same methods
3. **Easier testing**: Mock the service instead of fetch
4. **Type safety**: Return types are defined
5. **DRY principle**: Don't repeat URL construction

### What is async/await?

**Answer**: `async/await` is syntactic sugar for working with Promises, making asynchronous code look synchronous.

**Without async/await**:
```typescript
fetch(url)
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error(error));
```

**With async/await**:
```typescript
try {
  const response = await fetch(url);
  const data = await response.json();
  console.log(data);
} catch (error) {
  console.error(error);
}
```

---

## 6. Vite Build Tool

### What is Vite?

**Answer**: Vite (French for "fast") is a modern build tool and dev server for frontend projects.

**Key features**:
- **Fast dev server**: Uses ES modules, no bundling during dev
- **Hot Module Replacement (HMR)**: Updates page without full reload
- **Optimized builds**: Uses Rollup for production
- **TypeScript support**: Built-in, no configuration needed
- **Fast startup**: Cold start in milliseconds

### Why use Vite instead of Create React App?

**Answer**:
1. **Much faster**: Vite starts in ~100ms vs CRA's ~30 seconds
2. **Better HMR**: Changes reflect instantly
3. **Modern**: Uses ES modules natively
4. **Simpler**: Less configuration needed
5. **Industry standard**: Widely adopted

### What is Hot Module Replacement (HMR)?

**Answer**: HMR updates modules in the browser without a full page reload, preserving application state.

**Example**:
- You change a CSS color
- Vite injects the new CSS
- Page updates without losing your form data or scroll position

---

## 7. Nginx Web Server

### What is Nginx?

**Answer**: Nginx (pronounced "engine-x") is a high-performance web server and reverse proxy.

**Used for**:
- Serving static files (HTML, CSS, JS, images)
- Reverse proxy (forwarding API requests to backend)
- Load balancing
- SSL/TLS termination

### Why use Nginx for production?

**Answer**:
1. **Performance**: Much faster at serving static files than Node.js
2. **Security**: Battle-tested, handles malicious requests
3. **Caching**: Can cache responses for speed
4. **Compression**: Gzip compression reduces bandwidth
5. **Industry standard**: Used by Netflix, Airbnb, etc.

### Our nginx.conf explained:

```nginx
server {
    listen 80;                              # Listen on port 80
    root /usr/share/nginx/html;             # Serve files from this directory
    index index.html;                       # Default file

    # SPA routing - always serve index.html
    location / {
        try_files $uri $uri/ /index.html;   # For React Router
    }

    # Proxy API calls to backend
    location /api {
        proxy_pass http://backend:8000;     # Forward to backend container
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
}
```

**Why proxy API calls?**
- Avoids CORS issues (same origin for frontend and backend)
- Single domain for entire app
- Can add caching, rate limiting, etc.

---

## 8. Docker Multi-Stage Builds

### What is a multi-stage build?

**Answer**: A multi-stage build uses multiple `FROM` statements in a Dockerfile, allowing you to copy artifacts from one stage to another while discarding unnecessary files.

**Our frontend Dockerfile**:
```dockerfile
# Stage 1: Build
FROM node:20-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci                    # Install dependencies
COPY . .
RUN npm run build            # Build React app → dist/ folder

# Stage 2: Production
FROM nginx:1.27-alpine

# Copy only built files (not node_modules!)
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Why use multi-stage builds?

**Answer**:

**Without multi-stage** (Bad):
- Image includes: Node.js, npm, node_modules, source code, build tools
- Image size: ~500MB
- Security risk: Build tools in production image

**With multi-stage** (Good):
- Final image includes: Nginx + built files (HTML, CSS, JS)
- Image size: ~25MB (20x smaller!)
- Security: No build tools, no source code, no vulnerabilities from dev dependencies

**Benefits**:
1. **Smaller images**: Faster deployment, less storage cost
2. **Security**: Smaller attack surface
3. **Faster startup**: Less data to load
4. **Cleaner**: Only production dependencies

---

## 9. Environment Variables

### What are environment variables?

**Answer**: Environment variables are key-value pairs that configure your application for different environments (development, staging, production).

### Why use environment variables?

**Answer**:
1. **Different configs per environment**: Dev uses localhost, production uses real domain
2. **Security**: Keep secrets out of source code
3. **Flexibility**: Change config without rebuilding
4. **12-Factor App principle**: Configuration in environment, not code

### Vite environment variables

**In Vite, environment variables must start with `VITE_`**:

```bash
# .env.example
VITE_API_URL=http://localhost:8000
VITE_MAX_FILE_SIZE=10485760
VITE_ALLOWED_FILE_TYPES=audio/mpeg,audio/mp3
```

**Usage in code**:
```typescript
const apiUrl = import.meta.env.VITE_API_URL;
const maxSize = Number(import.meta.env.VITE_MAX_FILE_SIZE);
```

### Why VITE_ prefix?

**Answer**:
- **Security**: Prevents accidentally exposing server-side secrets to client
- Only variables with `VITE_` prefix are bundled into the frontend code
- Variables without prefix are only available to Vite build process

### .env.example vs .env vs .env.local

**Answer**:
- **`.env.example`**: Committed to Git, documents what variables are needed, uses safe default values
- **`.env`**: Not committed, contains actual values (may include secrets)
- **`.env.local`**: Not committed, overrides .env for local development

**For this project**: We use `.env.example` directly for simplicity (no secrets in frontend).

---

## 10. Validation Strategy

### Why validate on both client and server?

**Answer**:

**Client-side validation**:
- **Better UX**: Instant feedback, no waiting for server
- **Reduced load**: Invalid requests never reach server
- **Save bandwidth**: Don't upload invalid files

**Server-side validation**:
- **Security**: Never trust client (client can be bypassed)
- **Consistency**: Single source of truth
- **Protection**: Malicious users can't send bad data

**Both are necessary!**

### Our validation implementation:

**Client** (`services/validation.ts`):
```typescript
export function validateFile(file: File): ValidationResult {
  // Check file type
  if (!ALLOWED_TYPES.includes(file.type)) {
    return { valid: false, error: 'Invalid file type' };
  }

  // Check file size (10MB frontend limit)
  if (file.size > MAX_FILE_SIZE) {
    return { valid: false, error: 'File too large' };
  }

  return { valid: true };
}
```

**Server** (backend validates again with 15MB limit and deep file inspection).

### Why different size limits (10MB frontend, 15MB backend)?

**Answer**:
- **Frontend (10MB)**: Stricter, provides early feedback
- **Backend (15MB)**: Slightly more lenient to account for multipart encoding overhead
- **Principle**: Client validates for UX, server validates for security

---

## 11. Polling vs WebSockets

### What is polling?

**Answer**: Polling is repeatedly checking a server for updates at regular intervals.

**Our implementation**:
```typescript
const poll = async () => {
  const status = await apiService.getTaskStatus(taskId);

  if (status.status === 'completed') {
    // Done!
    return;
  }

  if (attempts < maxAttempts) {
    setTimeout(poll, 5000);  // Poll again in 5 seconds
  }
};
```

### What are WebSockets?

**Answer**: WebSockets provide a persistent, bidirectional connection between client and server. Server can push updates to client without client asking.

### Why use polling instead of WebSockets?

**Answer**:

**Advantages of polling (what we chose)**:
- ✅ **Simpler**: No special server setup, works with any HTTP server
- ✅ **Firewall friendly**: Uses regular HTTP, no connection issues
- ✅ **Stateless**: Easy to load balance across multiple servers
- ✅ **Sufficient for our use case**: 5-second updates are fast enough

**Advantages of WebSockets**:
- ✅ **Real-time**: Instant updates
- ✅ **Efficient**: No repeated HTTP overhead
- ✅ **Less latency**: Server pushes immediately

**For our use case**: Transcription takes 30-60 seconds. Polling every 5 seconds is perfectly adequate. WebSockets would be overkill.

**When to use WebSockets**:
- Chat applications (need instant messages)
- Live dashboards (stock prices, monitoring)
- Multiplayer games
- Collaborative editing

---

## 12. Debouncing

### What is debouncing?

**Answer**: Debouncing delays execution of a function until after a wait period has elapsed since the last time it was invoked.

**Use case**: Search input

**Without debouncing**:
```
User types: "t" → API call
User types: "e" → API call
User types: "s" → API call
User types: "t" → API call
Result: 4 API calls
```

**With debouncing (500ms)**:
```
User types: "t" → Wait 500ms
User types: "e" → Cancel previous timer, wait 500ms
User types: "s" → Cancel previous timer, wait 500ms
User types: "t" → Cancel previous timer, wait 500ms
User stops typing → 500ms passes → API call
Result: 1 API call
```

### Implementation in SearchBar:

```typescript
const [query, setQuery] = useState('');
const [debouncedQuery, setDebouncedQuery] = useState('');

useEffect(() => {
  const timer = setTimeout(() => {
    setDebouncedQuery(query);  // Update after 500ms
  }, 500);

  return () => clearTimeout(timer);  // Cleanup: cancel timer
}, [query]);

useEffect(() => {
  if (debouncedQuery) {
    onSearch(debouncedQuery);  // Only call when user stops typing
  }
}, [debouncedQuery]);
```

### Why 500ms?

**Answer**:
- Too short (100ms): Still too many calls, user might not be done
- Too long (2000ms): Feels unresponsive
- 500ms: Sweet spot - feels instant but reduces calls by 80-90%

---

## 13. UI/UX Design

### What makes good UX for file uploads?

**Answer**:

1. **Multiple input methods**: Drag-drop AND click to browse
2. **Visual feedback**: Highlight drop zone when dragging
3. **Progress indication**: Show upload status for each file
4. **Error messages**: Clear explanation of what went wrong
5. **Status updates**: Show processing → completed
6. **Non-blocking**: User can upload more files while others process

### Why scrollable transcription list?

**Answer**:
- **Prevents infinite page height**: Better performance
- **Always accessible UI**: Header and upload section stay visible
- **Sticky table headers**: Column names stay visible while scrolling
- **Better UX**: User doesn't have to scroll entire page

### CSS for scrolling:

```css
.transcription-list {
  max-height: 500px;      /* Fixed height */
  overflow-y: auto;       /* Scroll when content exceeds height */
}

.transcription-list thead {
  position: sticky;       /* Header stays at top */
  top: 0;
  background: #f5f5f5;    /* Solid background (not transparent) */
  z-index: 1;             /* Above table body */
}
```

### Status badges - why different colors?

**Answer**:
- **Visual hierarchy**: User can quickly scan status
- **Color meaning**: Green (success), Blue (in progress), Red (error)
- **Accessibility**: Color + text (not color alone)

```css
.status-badge.processing {
  background: #e3f2fd;  /* Light blue */
  color: #1976d2;       /* Dark blue text */
}

.status-badge.completed {
  background: #e8f5e9;  /* Light green */
  color: #388e3c;       /* Dark green text */
}

.status-badge.failed {
  background: #ffebee;  /* Light red */
  color: #d32f2f;       /* Dark red text */
}
```

---

## 14. Testing Strategy

### What testing tools do we use?

**Answer**:
- **Vitest**: Test runner (like Jest but faster, built for Vite)
- **Testing Library**: Utilities for testing React components
- **jsdom**: Simulates browser environment in Node.js

### Why Vitest instead of Jest?

**Answer**:
1. **Vite integration**: Reuses Vite config, no duplication
2. **Faster**: Significantly faster than Jest
3. **ES modules**: Native ESM support
4. **Compatible**: Jest-like API, easy to learn

### What do we test?

**Answer**:

**API Service** (`api.test.ts`):
- Test all API methods (upload, status, list, search)
- Mock fetch to avoid real network calls
- Verify correct URLs and request formats
- Test error handling

**FileUpload Component** (`FileUpload.test.tsx`):
- Render drop zone
- Validate files before upload
- Handle upload success/failure
- Poll for status updates

**TranscriptionList Component** (`TranscriptionList.test.tsx`):
- Show loading state
- Show empty state when no data
- Render transcriptions table
- Display status badges correctly
- Verify scrollable container

### Why mock fetch?

**Answer**:
- **Speed**: Tests run in milliseconds, not seconds
- **Reliability**: No network flakiness
- **Isolation**: Test component logic, not API
- **No dependencies**: Can run tests offline

---

## 15. Security Considerations

### What security measures are in the frontend?

**Answer**:

1. **Client-side file validation**: Check type and size before upload
2. **Input sanitization**: Prevent XSS in search queries
3. **Type safety**: TypeScript catches many bugs
4. **HTTPS (production)**: Encrypted communication
5. **Content Security Policy**: Via Nginx headers

### XSS Prevention:

**sanitize.ts**:
```typescript
export function sanitizeInput(input: string): string {
  const div = document.createElement('div');
  div.textContent = input;  // Automatically escapes HTML
  return div.innerHTML;
}
```

**Why is this safe?**
- `textContent` treats input as plain text, not HTML
- Even if user types `<script>alert('xss')</script>`, it becomes literal text

### Security headers in Nginx:

```nginx
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
```

**What they do**:
- **X-Frame-Options**: Prevents clickjacking (site can't be framed)
- **X-Content-Type-Options**: Prevents MIME sniffing attacks
- **X-XSS-Protection**: Browser's XSS filter enabled

### Why validate on client if server validates anyway?

**Answer**: Defense in depth!
- **Client validation**: Better UX, saves bandwidth
- **Server validation**: Security, can't be bypassed
- **Together**: Best of both worlds

---

## Quick Reference Card

### Component Responsibilities
- **App.tsx**: Main container, fetches data, manages global state
- **FileUpload**: Drag-drop, validation, upload, polling
- **TranscriptionList**: Display scrollable table
- **SearchBar**: Debounced search input

### Key React Hooks
- `useState`: Add state to component
- `useEffect`: Side effects (fetch data, timers)
- `useCallback`: Memoize functions

### API Methods
- `uploadFiles(files)`: Upload MP3 files
- `getTaskStatus(taskId)`: Poll task status
- `listTranscriptions()`: Get all transcriptions
- `searchTranscriptions(query)`: Search by filename

### Environment Variables
- `VITE_API_URL`: Backend URL
- `VITE_MAX_FILE_SIZE`: Max file size (bytes)
- `VITE_ALLOWED_FILE_TYPES`: Comma-separated MIME types

### Polling Config
- Interval: 5 seconds
- Max attempts: 60 (5 minutes total)
- Triggers: onUploadComplete()

### Debouncing
- Delay: 500ms
- Triggers search when user stops typing

### Docker Build
- Stage 1: node:20-alpine (build)
- Stage 2: nginx:1.27-alpine (serve)
- Final size: ~25MB

### File Size Limits
- Frontend validation: 10MB
- Backend limit: 15MB

---

## Common Interview Questions

### 1. Why React over Vue or Angular?

**Answer**:
- Large ecosystem and community
- TypeScript support
- Simple component model
- Our app is relatively simple - React is sufficient

### 2. How would you optimize performance?

**Answer**:
- Use React.memo() for expensive components
- Lazy loading for code splitting
- Virtual scrolling for very large lists
- Service Worker for offline support
- CDN for static assets

### 3. How would you handle authentication?

**Answer**:
- Store JWT in httpOnly cookie (secure)
- Context API for auth state
- Protected routes wrapper component
- Refresh token rotation

### 4. How do you handle errors?

**Answer**:
- Try-catch in async functions
- Error boundaries for React errors
- Display user-friendly error messages
- Log errors to monitoring service (Sentry)

### 5. What would you add for production?

**Answer**:
- Error monitoring (Sentry)
- Analytics (Google Analytics)
- Performance monitoring
- E2E tests (Playwright)
- CI/CD pipeline
- Accessibility audit
- SEO optimization

---

**End of Study Guide**
